<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/home',function () {
     return view('/auth/login');
});
Route::get('/', function () {
     return view('/auth/login');
});
Route::post('password/reset','Auth\ForgotPasswordController@resetPassword');
Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home','CompanyController@index')->name('home');
Route::get('/forgotPassword', 'ForgotPasswordController@getForgotPassword')->name('forgotPassword');
Route::post('/forgotPassword', 'ForgotPasswordController@postForgotPassword')->name('forgotPassword');


Route::get('/company','CompanyController@index')->name('company');
Route::get('/company/','CompanyController@index')->name('company.index');

Route::get('/company/create','CompanyController@create');
Route::post('/company/store','CompanyController@store')->name('company.store');
Route::get('/company/edit/{id}', 'CompanyController@edit')->name('company.edit');
Route::post('/company/update/{id}', 'CompanyController@update')->name('company.update');
Route::get('/company/delete/{id}','CompanyController@destroy');
Route::get('/company/profile/{id}', 'CompanyController@show')->name('company.profile');
Route::get('/password/change','ChangePasswordController@create');
Route::post('/password/change','ChangePasswordController@store')->name('change.password');
Route::get('/profile/{id}/edit','ProfileController@edit')->name('profile.edit');
Route::post('/profile/{id}/edit','ProfileController@update')->name('profile.update');
Route::get('/menu_template/', 'CompanyController@menu')->name('menu_template');

//Clear Cache facade value:
Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    return '<h1>Cache facade value cleared</h1>';
});

//Reoptimized class loader:
Route::get('/optimize', function() {
    $exitCode = Artisan::call('optimize');
    return '<h1>Reoptimized class loader</h1>';
});

//Route cache:
Route::get('/route-cache', function() {
    $exitCode = Artisan::call('route:cache');
    return '<h1>Routes cached</h1>';
});

//Clear Route cache:
Route::get('/route-clear', function() {
    $exitCode = Artisan::call('route:clear');
    return '<h1>Route cache cleared</h1>';
});

//Clear View cache:
Route::get('/view-clear', function() {
    $exitCode = Artisan::call('view:clear');
    return '<h1>View cache cleared</h1>';
});

//Clear Config cache:
Route::get('/config-cache', function() {
    $exitCode = Artisan::call('config:cache');
    return '<h1>Clear Config cleared</h1>';
});


Route::get('searchajax',array('as'=>'searchajax','uses'=>'CompanyController@autoComplete'));
Route::post('/autocomplete/fetch', 'CompanyController@fetch')->name('autocomplete.fetch');


