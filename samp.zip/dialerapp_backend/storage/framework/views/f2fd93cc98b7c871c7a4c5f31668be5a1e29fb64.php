<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\dialerapp_backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>