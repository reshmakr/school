<?php $__env->startSection('content'); ?>
 <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        
       
          
          <?php echo e(csrf_field()); ?>

        <div class="modal-body">
        <p class="text-center">
          Are you sure you want to delete this?
        </p>
            <input type="hidden" name="company_id" id="companyid" value="">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">No, Cancel</button>
          <button type="button" id="delete" class="btn btn-warning">Yes, Delete</button>
        </div>
      
      </div>
    </div>
  </div>
<div class="container">
 <div class="box">
<div class="box-body"> 
    <div class="row profile">
        <div class="col-md-12">
           <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                <div class="row">
            				<div class="col-md-6">
            				<div class="bs-example margin">
                        <form>
                            <div class="input-group">
                                  <input type="text" id="filter_name" name="filter_name" class="form-control"  placeholder="Search by Company name or Phone #" autocomplete="off">
                                      <span class="input-group-btn">
                                        <button type="submit" class="btn btn-info btn-flat">Search</button>
                                      </span>
                            </div>
                                
                        </form>
                    </div>
            				</div>
            				<div class="col-md-6">
                      <div class="bs-example margin">
            				<a href="<?php echo e(action('CompanyController@create')); ?>" class="btn btn-info btn-flat"><span class="glyphicon glyphicon-plus"></span>Add Company</a>
            				</div>
                  </div>
				        </div>
                
				</br>
              </br>
            </div>
                <div class="panel-body">
                    <div class="col-md-8">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                  <?php if(count($companies)==0): ?>
                          <div class="alert alert-warning">
                              <strong>Sorry!</strong> No Companies Found
                           </div> 
                      <?php else: ?>
                    <table class="table table-hover">
                              <thead>
                                <tr>
                                  <th scope="col">#</th>
                                   <th>Company Name</th>
                                    <th>Company Phone #</th>
									<th></th>
                                </tr>
                              </thead>
                              <tbody>
                                 
                                 <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                  <th scope="row"><?php echo e($company->id); ?></th>
                                  <td><a href="<?php echo e(url('company/profile/'.$company->id)); ?>"><?php echo e($company->name); ?></a></td>
                                  <td>
                                                            <?php 
                                                            if($company->phone_numbers){
                                                                 $phone_numbers=explode(",", $company->phone_numbers);
                                                                 if($phone_numbers && $phone_numbers[0]){
																	 $phone = preg_replace("~[^0-9]~", "", $phone_numbers[0]);
																	preg_match('~([0-9]{3})([0-9]{3})([0-9]{4})~', $phone, $matches);
                                                                    echo '('.$matches[1].') '.$matches[2].'-'.$matches[3];
                                                                    if(count($phone_numbers) >1){ ?>
                                                                       
                                                                        <a href="<?php echo e(route('company.edit',$company->id)); ?>" class="btn-link btn-link-sm">More</a>
                                                                    <?php }
                                                                 }else{
                                                                    echo $company->phone_numbers;
                                                                 }
                                                            }
                                                                ?>
                                                      </td>
													  <td> 
      <button class="btn btn-danger btn-xs delete" data-toggle="modal" data-companyid="$company->id" data-target="#deleteModal" data-url="<?php echo e(url('/company/delete/'.$company->id)); ?>">Remove</button>
      
   
													  </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </tbody>
                            </table>

                                 <?php endif; ?>
                            <?php echo e($companies->links()); ?>

                          </div>
                          <div class="col-md-4"></div>
                </div>
            </div>
        </div>
    </div>
</div>
 </div>
</div>
 <script type="text/javascript">
   $(document).ready(function() {
    src = "<?php echo e(route('searchajax')); ?>";
     $("#filter_name").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: src,
                dataType: "json",
                data: {
                    term : request.term
                },
                success: function(data) {
                    response(data);
                   
                }
            });
        },
        minLength: 3,
       
    }); 
      $('.delete').click(function(){

        url = $(this).data('url');
        $('#delete').click(function(){
        location.href = url

        })
      })
});

</script>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dialerapp_backend\resources\views/company/index.blade.php ENDPATH**/ ?>