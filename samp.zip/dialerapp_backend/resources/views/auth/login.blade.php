@extends('layouts.app')

@section('content')

<div class="login-box">
  <div class="login-logo">
    <a href="" style="color: #fff;"><img width="35%" src="{{ asset('images/logo.png')}}"></br><b>Dialer</b>App</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
    @if(isset(Auth::user()->email))
       <!--  <script>window.location="/home"</script> -->
        @endif
        @if($message = Session::get('error'))
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong>{{ $message }}</strong>
            </div>  
        @endif      
        @if (count($errors)>0)
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach 
                </ul>
            </div>
      @endif 
        @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

    <form id="form-validation" name="form-validation" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}
      <div class="form-group has-feedback">
        <input  placeholder="Username" id="validation-email" class="form-control" name="email" type="text" data-validation="[NOTEMPTY]>
        <span class="glyphicon glyphicon-envelope form-control-feedback" value="{{ old('email') }}"></span>
      </div>
      <div class="form-group has-feedback">
        <input id="validation-password" class="form-control password" name="password" type="password" data-validation="[L>=6]" data-validation-message="$ must be at least 6 characters" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="">
        
        <!-- /.col -->
        <div class="d-flex justify-content-center">
          <button type="submit" class="btn btn-success btn-block ">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <!-- /.social-auth-links -->
   <a data-target="#modalforget" data-toggle="modal" class="pull-right cat__core__link--blue cat__core__link--underlined">Forgot Password?</a>
   <br/>
<!--     <a href="register.html" class="text-center">Register a new membership</a> -->

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

  <div class="modal fade" id="modalforget" tabindex="-1"   data-width="760px" >
      <form id="forgetdata" name="form-validation" method="POST" action="{{ URL::to('password/reset') }}">
    <div class="modal-dialog" style="width:760px !important;">
    <div class="modal-content" style="background-color:#fff;padding:20px;border-radius:12px !important;">
        <div class="modal-header">
          
          <div class="form-title"> <h3>Forgot Password</h3> </div>
        </div>
        {{ csrf_field() }}
        <div class="modal-body" style="height:auto !important;">
          
          <div class="row">
            <div id="forgot-password-status"></div>
            <div class="text-error" id="error"></div>
          </div>
          <div class="row">
            <div class="col-md-10">
                <div class="form-group">
                <input class="form-control required" type="email" autocomplete="off" placeholder="Email Address"  id="forget_email" name="forgotemail" />
                        <span class="my-error-class" id="email_status"></span>
              </div>
          </div>
          <div class="clearfix"></div>
          
        {{ csrf_field() }}
      </div>

        <div class="row">
  <div class="col-md-10">
     <button type="button" value="Cancel" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
          <button type="button" value="Submit" id="submitButton" class="btn btn-success mr-3 pull-right">Submit</button>
         
        </div>

      </div>
        </div>
      </div>
      </form> 
  </div>
 <script type="text/javascript">
$('#modalforget').on('hidden.bs.modal', function () {
  $('#forgot-password-status').text('');
   $('#forget_email').val('');
    $(this).find('form').trigger('reset');
})
 $('#submitButton').click(function(){ var token = $("input[name=_token]").val();
    var email = $("#forget_email").val();

    if (email == "") {
      $("#forget_email").css("border","2px solid #ff1505");

      return false;

    } else {
      $("#forget_email").css("border","2px solid");
    }

    var data = {
      "_token": token,
      "email": email,
    };

    $.ajax({
      type: "POST",
      url: "{{ route('password.email') }}",
      data: data,
      dataType: 'json',
      success: function (data,xhr) {
        console.log(xhr.status);
        $("#forgot-password-status").html('Check your email and click the link<br/><br/>');
      },
      error: function (xhr) {
        $('#forget_email').val();
        if(xhr.status==200)
        $("#forgot-password-status").html('Check your email and click the link<br/><br/>');

      }
    });
    //window.location.reload();    //return false;
});
</script>
@endsection
