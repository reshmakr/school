<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyPhoneNumbers extends Model
{
    //
     protected $table = 'company_phone_numbers';
    
}
