<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->app['validator']->extend('numericarray', function ($attribute, $value, $parameters)
        { 
            foreach ($value as $v) { 
                if (!is_numeric($v) || strlen((string)$v)!=10 ){ 
                    return false;
                }
            }
            return true;
        });

    }
}
