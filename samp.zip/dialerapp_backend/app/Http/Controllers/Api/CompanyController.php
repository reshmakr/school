<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Company;
use Illuminate\Support\Facades\Auth; 
use Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
class CompanyController extends Controller 
{
public $successStatus = 200;


    public function filter()
    {

        $phone_number=request('phone_number');
        $app_client_token=request('app_client_token');
        $app_client=request('app_client');
        $limit=10;
        $offset=0;
        if(!empty($app_client_token) && !empty($app_client) && $app_client_token==config('app.app_client_token') && $app_client==config('app.app_client')){

            if(!empty($phone_number) && is_numeric($phone_number)){
              $companies_count=DB::table('company_phone_numbers')->leftJoin('companies', 'company_phone_numbers.company_id', '=', 'companies.id')->where('company_phone_numbers.phone_number', 'LIKE', '%' . $phone_number . '%')->where('company_phone_numbers.status', '=', 1)->select('company_phone_numbers.id','company_phone_numbers.company_id', 'company_phone_numbers.phone_number', 'companies.name')->count();

                $companies=DB::table('company_phone_numbers')->leftJoin('companies', 'company_phone_numbers.company_id', '=', 'companies.id')->where('company_phone_numbers.phone_number', 'LIKE', '%' . $phone_number . '%')->where('company_phone_numbers.status', '=', 1)->select('company_phone_numbers.id as company_phone_number_id','company_phone_numbers.company_id', 'company_phone_numbers.phone_number', 'companies.name','companies.city','companies.company_logo')->offset($offset)->limit($limit)->get()->toArray();
               
               
                $success['phone_number'] = $phone_number;
                $success['limit'] = $limit;
                $success['offset'] = $offset;
                $success['total'] = $companies_count;
                $success['list'] = $companies;
                 return response()->json(['message'=>'success','success' => $success], $this-> successStatus);

            }else{
                return response()->json(['message'=>'error','error' => 'Invalid Phone Number Format'], $this-> successStatus); 
            }
        }else{
            return response()->json(['message'=>'error','error'=>'Unauthorised'], 401); 
        }
        
    }
    public function filterCompany()
    {

        $company_name=request('name');
        $app_client_token=request('app_client_token');
        $app_client=request('app_client');
        $limit=10;
        $offset=0;
        if(!empty($app_client_token) && !empty($app_client) && $app_client_token==config('app.app_client_token') && $app_client==config('app.app_client')){

            if(!empty($company_name)){
             
               $companies_count=DB::table('company_phone_numbers')->leftJoin('companies', 'company_phone_numbers.company_id', '=', 'companies.id')->where('companies.name', 'LIKE', '%' . $company_name . '%')->where('companies.status', '=', 1)->where('company_phone_numbers.status', '=', 1)->select('company_phone_numbers.id','company_phone_numbers.company_id', 'company_phone_numbers.phone_number', 'companies.name')->count();

                $companies=DB::table('company_phone_numbers')->leftJoin('companies', 'company_phone_numbers.company_id', '=', 'companies.id')->where('companies.name', 'LIKE', '%' . $company_name . '%')->where('companies.status', '=', 1)->where('company_phone_numbers.status', '=', 1)->select('company_phone_numbers.id','company_phone_numbers.company_id', 'company_phone_numbers.phone_number', 'companies.name')->offset($offset)->limit($limit)->get()->toArray();
               
                $success['company_name'] = $company_name;
                $success['limit'] = $limit;
                $success['offset'] = $offset;
                $success['total'] = $companies_count;
                $success['list'] = $companies;
                 return response()->json(['message'=>'success','success' => $success], $this-> successStatus);

            }else{
                return response()->json(['message'=>'error','error' => 'Invalid Name Format'], $this-> successStatus); 
            }
        }else{
            return response()->json(['message'=>'error','error'=>'Unauthorised'], 401); 
        }
        
    }
    
    public function menuList()
    {

        $company_id=request('company_id');
        $phone_number=request('phone_number');
        $app_client_token=request('app_client_token');
        $app_client=request('app_client');
        if(!empty($app_client_token) && !empty($app_client) && $app_client_token==config('app.app_client_token') && $app_client==config('app.app_client')){

            if(!empty($phone_number) && is_numeric($phone_number)){

               $company_details =DB::table('company_phone_numbers')->leftJoin('companies', 'company_phone_numbers.company_id', '=', 'companies.id')->where('company_phone_numbers.phone_number', '=',$phone_number)->where('company_phone_numbers.status', '=', 1)->select('company_phone_numbers.id as company_phone_number_id','company_phone_numbers.company_id', 'company_phone_numbers.phone_number', 'companies.name','companies.city','companies.company_logo','companies.menu_json')->get()->toArray();
               if($company_details && isset($company_details[0])){
                if($company_details[0]->menu_json){

                     $menu_json_decode=json_decode($company_details[0]->menu_json,true);
                     foreach($menu_json_decode as $keyid){
                        $menuArray[]=$keyid;
                     }
                     
                    $success['company_id'] = $company_details[0]->company_id;
                    $success['phone_number'] = $phone_number;
                    $success['company_details']['name'] = $company_details[0]->name;
                    $success['company_details']['city'] = isset($company_details[0]->city)?$company_details[0]->city:'';
                    $success['company_details']['company_logo']= isset($company_details[0]->company_logo)?$company_details[0]->company_logo:'';
                    $success['company_details']['list']=$menuArray;
                     return response()->json(['message'=>'success','success' => $success], $this-> successStatus);
                }else{
                    return response()->json(['message'=>'error','error' => 'No Menus found'], $this-> successStatus);
                }
                    
               }else{
                return response()->json(['message'=>'error','error' => 'Invalid Phone Number'], $this-> successStatus);
               }
               

            }else{
                return response()->json(['message'=>'error','error' => 'Invalid Phone Number Format'], $this-> successStatus); 
            }
        }else{
            return response()->json(['message'=>'error','error'=>'Unauthorised'], 401); 
        }
        
    }
    
}