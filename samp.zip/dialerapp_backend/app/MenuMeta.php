<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuMeta extends Model
{
    //
      protected $table = 'menu_meta';
}
