<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_social_urls extends Model
{
    //
}
