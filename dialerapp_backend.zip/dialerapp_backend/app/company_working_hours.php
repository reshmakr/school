<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_working_hours extends Model
{
    //
}
