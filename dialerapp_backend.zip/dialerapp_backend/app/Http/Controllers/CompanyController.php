<?php

namespace App\Http\Controllers;
use App\Company;
use App\CompanyPhoneNumbers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Intervention\Image\Facades\Image;
use session;
use Illuminate\Validation\Rule;
class CompanyController extends Controller
{
	 /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filter_company=Input::get('filter_name');

        if(isset($filter_company)){
            $companies = Company::where('name', $filter_company)->orWhere('name', 'like', '%' . $filter_company . '%')->orWhere('phone_numbers', 'like', '%' . $filter_company . '%')->paginate(10);
        
        }else{
            $companies = Company::where('status', 1)->paginate(10);
        }
        

        
        
        return view('company.index',compact('companies'));
    }
        /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         

        return view('company.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
         $this->validate($request, [
            'name' => Rule::unique('companies')->where(function ($query) {
                     $query->where('status', 1);
                     })
        ]);
         $validator = Validator::make($request->all(), [
            'name' => 'required|max:200|regex:/^[\pL\s\-]+$/u|unique:companies',
            'company_phone_numbers' => 'required|min:1|numericarray',
            'website' => 'sometimes|nullable|regex:/^http:\/\/\w+(\.\w+)*(:[0-9]+)?\/?$/',
            'company_address1'=>'sometimes|nullable|alpha_dash',
            'company_address2'=>'sometimes|nullable|alpha_dash',
            'state'=>'sometimes|nullable|alpha_dash',
            'city'=>'sometimes|nullable|alpha_dash',
            'zipcode'=>'sometimes|nullable|alpha_dash',
            'company_logo'=>'sometimes|nullable|image|mimes:jpg,jpeg,png|max:500000',
            'monday.from_time'=>'sometimes|nullable|date_format:H:i',
            'monday.to_time'=>'required_with:monday.from_time|sometimes|nullable|date_format:H:i',
            'tuesday.from_time'=>'sometimes|nullable|date_format:H:i',
            'tuesday.to_time'=>'required_with:tuesday.from_time|sometimes|nullable|date_format:H:i',
            'wednesday.from_time'=>'sometimes|nullable|date_format:H:i',
            'wednesday.to_time'=>'required_with:wednesday.from_time|sometimes|nullable|date_format:H:i',
            'thursday.from_time'=>'sometimes|nullable|date_format:H:i',
            'thursday.to_time'=>'required_with:thursday.from_time|sometimes|nullable|date_format:H:i',
            'friday.from_time'=>'sometimes|nullable|date_format:H:i',
            'friday.to_time'=>'required_with:friday.from_time|sometimes|nullable|date_format:H:i',
            'saturday.from_time'=>'sometimes|nullable|date_format:H:i',
            'saturday.to_time'=>'required_with:saturday.from_time|sometimes|nullable|date_format:H:i',
            'sunday.from_time'=>'sometimes|nullable|date_format:H:i',
            'sunday.to_time'=>'required_with:sunday.from_time|sometimes|nullable|date_format:H:i',
            'facebook_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'twitter_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'instagram_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'yelp_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'pinterest_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'contact_name' => 'sometimes|nullable||regex:/^[\pL\s\-]+$/u',
            'contact_phone' => 'sometimes|nullable||numeric|digits_between:10,10',
            'contact_email' => 'sometimes|nullable||email',
        ], [
            'company_name.required' => "Company Name is required",
            'company_phone_numbers' => 'Company Phone Number is required',
        ]);
        if ($validator->fails()) {
           // \Session::flash('error_msg', 'Please fill required fields');
            return redirect()->back()->withErrors($validator->errors())->withInput();
        } else {
            $company_contact_numbers=$request->post('company_phone_numbers');
            if(count($company_contact_numbers) > 1){
            $company_contact_number=implode(",",$company_contact_numbers);
            }else{
                $company_contact_number=$company_contact_numbers[0];
            }
            $social_urls=array(
              "facebook" => $request->post('facebook_url'),
              "twitter" => $request->post('facebook_url'),
              "instagram" => $request->post('instagram_url'),
              "yelp" => $request->post('yelp_url'),
               "pinterest" => $request->post('pinterest_url')
            );
            $company_working_hours=array(
            "monday" => $request->post('monday'),
            "tuesday" => $request->post('tuesday'),
            "wednesday" => $request->post('wednesday'),
            "thursday" => $request->post('thursday'),
            "friday" => $request->post('friday'),
            "saturday" => $request->post('saturday'),
            "sunday" => $request->post('sunday')
            );
            
             $company = new \App\Company;
             $company->name = $request->post('name');
             $company->phone_numbers=$company_contact_number;
             $company->address1=$request->post('company_address1');
             $company->address2=$request->post('company_address1');
             $company->state=$request->post('state');
             $company->city=$request->post('city');
             $company->zip=$request->post('zipcode');
             $company->website=$request->post('website');
             $company->status=1;
             $company->contact_name=$request->post('contact_name');
             $company->contact_phone=$request->post('contact_phone');
             $company->contact_email=$request->post('contact_email');
             $company->social_urls=json_encode($social_urls);
             $company->working_hours=json_encode($company_working_hours);
             if($company->save()){
                $company_id=$company->id;
                //upload image
            if ($request->hasFile('company_logo')){ 
             
                    $company_logo = Company::find($company_id);
                   
                    $file = request()->file('company_logo');
                    $img = Image::make($request->company_logo)->resize(200,null,function ($constraint) {
                    $constraint->aspectRatio();
                    })->crop(200,150);
                    $imageName = time().'.'.$request->company_logo->getClientOriginalExtension();
                    $request->company_logo->move(public_path('images/'.$company_id.'/'), $imageName);

                    $img->save(public_path('images/'.$company_id.'/').'thumbnail_'.$imageName.'');
                    $company_logo->thumb='images/'.$company_id.'/'.'thumbnail_'.$imageName;
                    $company_logo->company_logo ='/images/'.$company_id.'/'.$imageName;
                    $company_logo->save();
                }
            //end image upload
            //save phone numbers
            if(count($company_contact_numbers) >= 1){
                foreach($company_contact_numbers as $numbers =>$phone_number_val){
                    $company_numbers = new \App\CompanyPhoneNumbers;
                    $company_numbers->company_id = $company_id;
                    $company_numbers->phone_number=$phone_number_val;
                    $company_numbers->save();
                }   
            }
            //end save phone numbers
             
                \Session::flash('success_msg', 'Company Added successfully!');
             }else{
                 \Session::flash('error_msg', 'Error Occured please try again later!');
             }
             
             
             

           
        }
        
         return redirect('/company');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $company = \App\Company::find($id);
        $company->company_social_urls=json_decode($company->social_urls,true);
        $company->company_working_hours=json_decode($company->working_hours,true);
        $company->company_phone_numbers=explode(",",$company->phone_numbers);
      
        return view('company.show',compact('company'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $company = \App\Company::find($id);
        $company->company_social_urls=json_decode($company->social_urls,true);
        $company->company_working_hours=json_decode($company->working_hours,true);
       // $company->company_phone_numbers=explode(",",$company->phone_numbers);
        $company_contact_numbers = \App\CompanyPhoneNumbers::where('company_id',$id)->get();
         $company->company_phone_numbers=$company_contact_numbers;
//         foreach($company_contact_numbers as $number){
// echo '<pre>';print_r($number);
//         }
// die();
        return view('company.edit',compact('company'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function update($id, Request $request){
        $this->validate($request, [
            'name' => Rule::unique('companies')->where(function ($query) {
                     $query->where('id', '<>',$id);
                     })
        ]);
         $validator = Validator::make($request->all(), [
            'name' => 'required|max:200|regex:/^[\pL\s\-]+$/u|unique:companies',
            'company_phone_numbers' => 'required|min:1|numericarray',
            'website' => 'sometimes|nullable|regex:/^http:\/\/\w+(\.\w+)*(:[0-9]+)?\/?$/',
            'company_address1'=>'sometimes|nullable|alpha_dash',
            'company_address2'=>'sometimes|nullable|alpha_dash',
            'state'=>'sometimes|nullable|alpha_dash',
            'city'=>'sometimes|nullable|alpha_dash',
            'zipcode'=>'sometimes|nullable|alpha_dash',
            'company_logo'=>'sometimes|nullable|image|mimes:jpg,jpeg,png|max:500000',
            'monday.from_time'=>'sometimes|nullable|date_format:H:i',
            'monday.to_time'=>'required_with:monday.from_time|sometimes|nullable|date_format:H:i',
            'tuesday.from_time'=>'sometimes|nullable|date_format:H:i',
            'tuesday.to_time'=>'required_with:tuesday.from_time|sometimes|nullable|date_format:H:i',
            'wednesday.from_time'=>'sometimes|nullable|date_format:H:i',
            'wednesday.to_time'=>'required_with:wednesday.from_time|sometimes|nullable|date_format:H:i',
            'thursday.from_time'=>'sometimes|nullable|date_format:H:i',
            'thursday.to_time'=>'required_with:thursday.from_time|sometimes|nullable|date_format:H:i',
            'friday.from_time'=>'sometimes|nullable|date_format:H:i',
            'friday.to_time'=>'required_with:friday.from_time|sometimes|nullable|date_format:H:i',
            'saturday.from_time'=>'sometimes|nullable|date_format:H:i',
            'saturday.to_time'=>'required_with:saturday.from_time|sometimes|nullable|date_format:H:i',
            'sunday.from_time'=>'sometimes|nullable|date_format:H:i',
            'sunday.to_time'=>'required_with:sunday.from_time|sometimes|nullable|date_format:H:i',
            'facebook_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'twitter_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'instagram_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'yelp_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'pinterest_url' => 'sometimes|nullable|regex:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/',
            'contact_name' => 'sometimes|nullable||regex:/^[\pL\s\-]+$/u',
            'contact_phone' => 'sometimes|nullable||numeric|digits_between:10,10',
            'contact_email' => 'sometimes|nullable||email',
        ], [
            'company_name.required' => "Company Name is required",
            'company_phone_numbers' => 'Company Phone Number is required',
        ]);
        if ($validator->fails()) {
           // \Session::flash('error_msg', 'Please fill required fields');
            return redirect()->back()->withErrors($validator->errors())->withInput();
        } else {
            $company_contact_numbers=$request->post('company_phone_numbers');
            if(count($company_contact_numbers) > 1){
            $company_contact_number=implode(",",$company_contact_numbers);
            }else{
                $company_contact_number=$company_contact_numbers[0];
            }
            $social_urls=array(
              "facebook" => $request->post('facebook_url'),
              "twitter" => $request->post('facebook_url'),
              "instagram" => $request->post('instagram_url'),
              "yelp" => $request->post('yelp_url'),
               "pinterest" => $request->post('pinterest_url')
            );
            $company_working_hours=array(
            "monday" => $request->post('monday'),
            "tuesday" => $request->post('tuesday'),
            "wednesday" => $request->post('wednesday'),
            "thursday" => $request->post('thursday'),
            "friday" => $request->post('friday'),
            "saturday" => $request->post('saturday'),
            "sunday" => $request->post('sunday')
            );
            
             $company= Company::find($id);
             $company->name = $request->post('name');
             $company->phone_numbers=$company_contact_number;
             $company->address1=$request->post('company_address1');
             $company->address2=$request->post('company_address1');
             $company->state=$request->post('state');
             $company->city=$request->post('city');
             $company->zip=$request->post('zipcode');
             $company->website=$request->post('website');
             $company->status=1;
             $company->contact_name=$request->post('contact_name');
             $company->contact_phone=$request->post('contact_phone');
             $company->contact_email=$request->post('contact_email');
             $company->social_urls=json_encode($social_urls);
             $company->working_hours=json_encode($company_working_hours);
             if($company->save()){
                $company_id=$company->id;
                //upload image
            if ($request->hasFile('company_logo')){ 
             
                    $company_logo = Company::find($company_id);
                   
                    $file = request()->file('company_logo');
                    $img = Image::make($request->company_logo)->resize(200,null,function ($constraint) {
                    $constraint->aspectRatio();
                    })->crop(200,150);
                    $imageName = time().'.'.$request->company_logo->getClientOriginalExtension();
                    $request->company_logo->move(public_path('images/'.$company_id.'/'), $imageName);

                    $img->save(public_path('images/'.$company_id.'/').'thumbnail_'.$imageName.'');
                    $company_logo->thumb='images/'.$company_id.'/'.'thumbnail_'.$imageName;
                    $company_logo->company_logo ='/images/'.$company_id.'/'.$imageName;
                    $company_logo->save();
                }
            //end image upload
            //save phone numbers
            if(count($company_contact_numbers) >= 1){
                foreach($company_contact_numbers as $numbers =>$phone_number_val){
                    $company_numbers = new \App\CompanyPhoneNumbers;
                    $company_numbers->company_id = $company_id;
                    $company_numbers->phone_number=$phone_number_val;
                    $company_numbers->save();
                }   
            }
            /* //get post data
            $postData = $request->all();
            //update post data
            \App\Company::find($id)->update($postData); */
            
            //store status message
            \Session::flash('success_msg', 'Company updated successfully!');
        }else{
            \Session::flash('error_msg', 'Error Occured please try again later!');
        }

        return redirect()->route('company.index');
    }
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $company = \App\Company::find($id);
        $student = \App\Student::find($company->company_id);
        $company->delete();
        $company->students()->delete();
         return redirect()->route('company.index');
    }
     public function filter(Request $request, Company $company)
    {
         // Search for a user based on their company.
        if ($request->has('company')) {
            return $Company->where('name', $request->input('company'))
                ->get();
        }
        // Continue for all of the filters.

        // No filters have been provided, so
        // let's return all users. This is
        // bad - we should paginate in
        // reality.
        return Company::all();
    }
}
