<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }
    public function resetPassword()
      {
        $email =Input::get('email');
        var_dump($email);die();
        $user_email = DB::table('users')->where('email', $email)->first();
        if($user_email)
        {
             return response()->json(array('msg'=> 'success'), 200);
        }
        else
        {
            return response()->json(array('msg'=> 'error'), 200);
        }

    }
}
