-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2019 at 03:14 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dialer_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(75) NOT NULL,
  `phone_numbers` text NOT NULL,
  `address1` text,
  `address2` text,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `website` varchar(75) DEFAULT NULL,
  `company_logo` text,
  `thumb` text,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `social_urls` text,
  `working_hours` text,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `phone_numbers`, `address1`, `address2`, `city`, `state`, `zip`, `website`, `company_logo`, `thumb`, `contact_name`, `contact_phone`, `contact_email`, `social_urls`, `working_hours`, `status`, `created_at`, `updated_at`) VALUES
(15, 'Apple Inc', '8004002001,8004002002,8004002003,8004002004', NULL, NULL, 'cochin', 'kerala', 682309, '682309', NULL, 'images/19/thumbnail_1557398855.png', 'Steve james', '2145784512', 'abc@gmail.com', '{\"facebook\":\"www.facebook.com\\/infosys\",\"twitter\":\"www.facebook.com\\/infosys\",\"instagram\":\"www.instagram\\/infosys\",\"yelp\":\"www.yelp.com\\/infosys\",\"pinterest\":\"www.pinterest.com\\/infosys\"}', '{\"monday\":{\"from_time\":\"01:00\",\"to_time\":\"01:30\"},\"tuesday\":{\"from_time\":\"01:00\",\"to_time\":\"02:00\"},\"wednesday\":{\"from_time\":\"02:00\",\"to_time\":\"03:00\"},\"thursday\":{\"from_time\":\"03:00\",\"to_time\":\"04:00\"},\"friday\":{\"from_time\":\"04:00\",\"to_time\":\"05:00\"},\"saturday\":{\"from_time\":\"06:00\",\"to_time\":\"06:00\"},\"sunday\":{\"from_time\":\"07:00\",\"to_time\":\"07:00\"}}', 1, '2019-05-09 10:49:22', '2019-05-09 03:34:41'),
(16, 'acd', '2145784512', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'images/19/thumbnail_1557398855.png', NULL, NULL, NULL, '{\"facebook\":null,\"twitter\":null,\"instagram\":null,\"yelp\":null,\"pinterest\":null}', '{\"monday\":{\"from_time\":null,\"to_time\":null},\"tuesday\":{\"from_time\":null,\"to_time\":null},\"wednesday\":{\"from_time\":null,\"to_time\":null},\"thursday\":{\"from_time\":null,\"to_time\":null},\"friday\":{\"from_time\":null,\"to_time\":null},\"saturday\":{\"from_time\":null,\"to_time\":null},\"sunday\":{\"from_time\":null,\"to_time\":null}}', 1, '2019-05-09 10:49:25', '2019-05-09 05:05:19'),
(17, 'acde', '2145784512', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'images/19/thumbnail_1557398855.png', NULL, NULL, NULL, '{\"facebook\":null,\"twitter\":null,\"instagram\":null,\"yelp\":null,\"pinterest\":null}', '{\"monday\":{\"from_time\":null,\"to_time\":null},\"tuesday\":{\"from_time\":null,\"to_time\":null},\"wednesday\":{\"from_time\":null,\"to_time\":null},\"thursday\":{\"from_time\":null,\"to_time\":null},\"friday\":{\"from_time\":null,\"to_time\":null},\"saturday\":{\"from_time\":null,\"to_time\":null},\"sunday\":{\"from_time\":null,\"to_time\":null}}', 1, '2019-05-09 10:49:27', '2019-05-09 05:05:48'),
(18, 'acdef', '2145784512', NULL, NULL, NULL, NULL, NULL, NULL, '/images/18/1557398189.png', 'images/19/thumbnail_1557398855.png', NULL, NULL, NULL, '{\"facebook\":null,\"twitter\":null,\"instagram\":null,\"yelp\":null,\"pinterest\":null}', '{\"monday\":{\"from_time\":null,\"to_time\":null},\"tuesday\":{\"from_time\":null,\"to_time\":null},\"wednesday\":{\"from_time\":null,\"to_time\":null},\"thursday\":{\"from_time\":null,\"to_time\":null},\"friday\":{\"from_time\":null,\"to_time\":null},\"saturday\":{\"from_time\":null,\"to_time\":null},\"sunday\":{\"from_time\":null,\"to_time\":null}}', 1, '2019-05-09 10:49:30', '2019-05-09 05:06:29'),
(19, 'asd', '1478521452', NULL, NULL, NULL, NULL, NULL, NULL, '/images/19/1557398855.png', 'images/19/thumbnail_1557398855.png', NULL, NULL, NULL, '{\"facebook\":null,\"twitter\":null,\"instagram\":null,\"yelp\":null,\"pinterest\":null}', '{\"monday\":{\"from_time\":null,\"to_time\":null},\"tuesday\":{\"from_time\":null,\"to_time\":null},\"wednesday\":{\"from_time\":null,\"to_time\":null},\"thursday\":{\"from_time\":null,\"to_time\":null},\"friday\":{\"from_time\":null,\"to_time\":null},\"saturday\":{\"from_time\":null,\"to_time\":null},\"sunday\":{\"from_time\":null,\"to_time\":null}}', 1, '2019-05-09 10:47:35', '2019-05-09 05:17:35');

-- --------------------------------------------------------

--
-- Table structure for table `company_phone_numbers`
--

CREATE TABLE `company_phone_numbers` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `dial_count` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_phone_numbers`
--

INSERT INTO `company_phone_numbers` (`id`, `company_id`, `phone_number`, `dial_count`, `created_at`, `updated_at`) VALUES
(1, 15, '8004002001', 0, '2019-05-09 03:34:41', '2019-05-09 03:34:41'),
(2, 15, '8004002002', 0, '2019-05-09 03:34:41', '2019-05-09 03:34:41'),
(3, 15, '8004002003', 0, '2019-05-09 03:34:41', '2019-05-09 03:34:41'),
(4, 15, '8004002004', 0, '2019-05-09 03:34:41', '2019-05-09 03:34:41'),
(5, 18, '2145784512', 0, '2019-05-09 05:06:29', '2019-05-09 05:06:29'),
(6, 19, '1478521452', 0, '2019-05-09 05:17:35', '2019-05-09 05:17:35');

-- --------------------------------------------------------

--
-- Table structure for table `menu_keys`
--

CREATE TABLE `menu_keys` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_keys`
--

INSERT INTO `menu_keys` (`id`, `name`, `slug`) VALUES
(1, 'Time Delayed Action', ''),
(2, 'Button 1', ''),
(3, 'Button 2', ''),
(4, 'Button 3', ''),
(5, 'Button 4', ''),
(6, 'Button 5', ''),
(7, 'Button 6', ''),
(8, 'Button 7', ''),
(9, 'Button 8', ''),
(10, 'Button 9', ''),
(11, 'Button 0', ''),
(12, 'Button *', ''),
(13, 'Button #', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu_meta`
--

CREATE TABLE `menu_meta` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_meta`
--

INSERT INTO `menu_meta` (`id`, `name`, `slug`) VALUES
(1, 'Dial Number', 'dial_number'),
(2, 'Split', 'split'),
(3, 'Spanish', 'spanish');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('reshma.k@segurotechnologies.com', '$2y$10$7t6b1E0iX7BFbeoDHD6ppOTGAx4aST0pukqgUGxJeegs1jVO3Dlqa', '2019-05-07 00:18:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'reshma.k@segurotechnologies.com', NULL, '$2y$10$woIFuunrNhOMwZrprApEd.oqCnDAtlYZUNBEOvAh.qQ2bra8DA3OK', NULL, 1, '2019-05-06 23:25:04', '2019-05-06 23:25:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_phone_numbers`
--
ALTER TABLE `company_phone_numbers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_keys`
--
ALTER TABLE `menu_keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_meta`
--
ALTER TABLE `menu_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `company_phone_numbers`
--
ALTER TABLE `company_phone_numbers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu_keys`
--
ALTER TABLE `menu_keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `menu_meta`
--
ALTER TABLE `menu_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
