
@extends('layouts.dashboard')

@section('content')

 <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        
        <div class="modal-body">
          <p>Confirm delete?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Comapny List</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
         
          <div class="row">
            <div class="col-xs-12 text-center">
               @if(Session::has('success_msg'))
                <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
                @endif
                 <a href="{{ action('CompanyController@create') }}" class="btn btn-green" style="float: right;padding:5px 10px; "><span class="glyphicon glyphicon-plus"></span>Add Company</a>
              </br>
              </br>
               @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
              <table class="table table-hover">
                <thead>
                  <tr>
                  <th scope="col">#</th>
                  <th>Company Name</th>
                  <th>Company Phone #</th>
                  </tr>
                </thead>
              <tbody>
                @if(count($companies)==0)
                <div class="alert alert-warning">
                <strong>Sorry!</strong> No Companies Found,Add Company
                </div> 
                @else
                @foreach($companies as $company)
                <tr>
                <th scope="row">{{$loop->index+1}}</th>
                <td><a href="{{ url('company/'.$company->id)}}">{{$company->name}}</a></td>
                <td>
                                <?php 
                                if($company->phone_numbers){
                                     $phone_numbers=explode(",", $company->phone_numbers);
                                     if($phone_numbers){
                                        echo $phone_numbers[0];
                                        if(count($phone_numbers) >1){
                                            echo ' <a href="" style="font-size:12px"> More</a>';
                                        }
                                     }else{
                                        echo $company->phone_numbers;
                                     }
                                }
                                    ?>
                          </td>
                </tr>

                @endforeach
                @endif
              </tbody>
              </table>
            </div>
          </div>
          
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
<div class="container">
  
    <div class="row profile">
        <div class="col-md-8 col-md-offset-2">
           @if(Session::has('success_msg'))
        <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
            <div class="panel panel-default">
                <div class="panel-heading">
                
                <a href="{{ action('CompanyController@create') }}" class="btn btn-green" style="float: right;padding:5px 10px; "><span class="glyphicon glyphicon-plus"></span>Add Company</a>
 </br>
              </br>
            </div>
                <div class="panel-body">

                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
       <th>Company Name</th>
        <th>Company Phone #</th>
    </tr>
  </thead>
  <tbody>
     @if(count($companies)==0)
        <div class="alert alert-warning">
            <strong>Sorry!</strong> No Companies Found,Add Company
         </div> 
    @else
     @foreach($companies as $company)
     <tr>
      <th scope="row">{{$loop->index+1}}</th>
      <td><a href="{{ url('company/'.$company->id)}}">{{$company->name}}</a></td>
      <td>
                                <?php 
                                if($company->phone_numbers){
                                     $phone_numbers=explode(",", $company->phone_numbers);
                                     if($phone_numbers){
                                        echo $phone_numbers[0];
                                        if(count($phone_numbers) >1){
                                            echo ' <a href="" style="font-size:12px"> More</a>';
                                        }
                                     }else{
                                        echo $company->phone_numbers;
                                     }
                                }
                                    ?>
                          </td>
    </tr>

    @endforeach
     @endif
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>
 
@section('script')
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
    $('#delete').click(function(){
    location.href = url

    })
  })
</script>
@endsection
@endsection



