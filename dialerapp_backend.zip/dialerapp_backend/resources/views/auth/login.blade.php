@extends('layouts.app')

@section('content')

<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>Dialer</b>App</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
    @if(isset(Auth::user()->email))
        <script>window.location="/home"</script>
        @endif
        @if($message = Session::get('error'))
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong>{{ $message }}</strong>
            </div>  
        @endif      
        @if (count($errors)>0)
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach 
                </ul>
            </div>
      @endif 
        @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

    <form id="form-validation" name="form-validation" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}
      <div class="form-group has-feedback">
        <input  placeholder="Username" id="validation-email" class="form-control" name="email" type="text" data-validation="[NOTEMPTY]>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input id="validation-password" class="form-control password" name="password" type="password" data-validation="[L>=6]" data-validation-message="$ must be at least 6 characters" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="">
        
        <!-- /.col -->
        <div class="d-flex justify-content-center">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <!-- /.social-auth-links -->
   <a href="{{ URL::to('password/reset') }}" class="pull-right cat__core__link--blue cat__core__link--underlined">Forgot Password?</a>
    <a data-target="#modalforget" data-toggle="modal" >I forgot my password</a>
<!--     <a href="register.html" class="text-center">Register a new membership</a> -->

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

  <div class="modal fade" id="modalforget" tabindex="-1"   data-width="760px" >
      <form id="forgetdata" name="form-validation" method="POST" action="{{ URL::to('password/reset') }}">
    <div class="modal-dialog" style="width:760px !important;">
    <div class="modal-content" style="background-color:#fff;padding:20px;border-radius:12px !important;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
          <div class="form-title"> <span class="form-title">Forget Password</span> </div>
        </div>
        {{ csrf_field() }}
        <div class="modal-body" style="height:auto !important;">
          <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <strong style="color: #666; font-size: large; ">&nbsp; &nbsp; &nbsp; &nbsp; Please enter your email. A password reset link will be sent to this email.</strong>
                  </div>
                </div>
            </div>
          <div class="row"></div>
          <div class="row">
            <div class="col-md-10">
              <div class="form-group">
                <div class="col-md-2"></div>
                <div class="col-md-10">

                <input class="form-control required" type="email" autocomplete="off" placeholder="Email"  id="forget_email" name="forgotemail" />
                        <span class="my-error-class" id="email_status"></span>
                </div>
              </div>
            </div>
          </div>
          <div class="text-success" id="forgot-password-status"></div>
        {{ csrf_field() }}
      <div class="modal-footer">
          <button type="button" value="Submit" id="submitButton" class="btn btn-primary mr-3">Submit</button>
          <button type="button" value="Cancel" class="btn default red" data-dismiss="modal">Cancel</button>
          <button type="reset" value="Clear" class="btn blue">Clear</button>
      </div>
        </div>
        </div>
      </div>
      </form> 
  </div>
 <script type="text/javascript">

 $('#submitButton').click(function(){ var token = $("input[name=_token]").val();
    var email = $("#forget_email").val();

    if (email == "") {
      $("#forget_email").css("border","2px solid #ff1505");

      return false;

    } else {
      $("#forget_email").css("border","2px solid");
    }

    var data = {
      "_token": token,
      "email": email,
    };

    $.ajax({
      type: "POST",
      url: "{{ route('password.email') }}",
      data: data,
      dataType: 'json',
      success: function (data) {
        $("#forgot-password-status").html("Forgot Password Successfully");
      },
      error: function (data) {
        $("#error").text('fail to send request');
      }
    });
    location.reload();
    //return false;
});
</script>
@endsection
