<?php $__env->startSection('content'); ?>

 <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        
        <div class="modal-body">
          <p>Confirm delete?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
<div class="container">
  
    <div class="row profile">
        <div class="col-md-12">
           <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                <div class="row">
            				<div class="col-md-8">
            				<div class="bs-example">
                        <form>
                            
                                  <div class="input-group">
                                      <input type="text" name="filter_name" class="form-control" placeholder="Search by Company name or Phone #" id="search-input-box">
                                      <div class="input-group-append">
                                          <button type="submit" class="btn btn-secondary btn-blu">
                                              Search
                                          </button>
                                      </div>
                                  </div>
                                
                        </form>
                    </div>
            				</div>
            				<div class="col-md-4">
            				<a href="<?php echo e(action('CompanyController@create')); ?>" class="btn btn-green" style="float: right;padding:5px 10px; "><span class="glyphicon glyphicon-plus"></span>Add Company</a>
            				</div>
				        </div>
                
				</br>
              </br>
            </div>
                <div class="panel-body">
                    <div class="col-md-8">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-hover">
                              <thead>
                                <tr>
                                  <th scope="col">#</th>
                                   <th>Company Name</th>
                                    <th>Company Phone #</th>
                                </tr>
                              </thead>
                              <tbody>
                                 <?php if(count($companies)==0): ?>
                                    <div class="alert alert-warning">
                                        <strong>Sorry!</strong> No Companies Found,Add Company
                                     </div> 
                                <?php else: ?>
                                 <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                  <th scope="row"><?php echo e($loop->index+1); ?></th>
                                  <td><a href="<?php echo e(url('company/profile/'.$company->id)); ?>"><?php echo e($company->name); ?></a></td>
                                  <td>
                                                            <?php 
                                                            if($company->phone_numbers){
                                                                 $phone_numbers=explode(",", $company->phone_numbers);
                                                                 if($phone_numbers){
                                                                    echo $phone_numbers[0];
                                                                    if(count($phone_numbers) >1){ ?>
                                                                       
                                                                        <a href="<?php echo e(route('company.edit',$company->id)); ?>" class="btn-link btn-link-sm">More</a>
                                                                    <?php }
                                                                 }else{
                                                                    echo $company->phone_numbers;
                                                                 }
                                                            }
                                                                ?>
                                                      </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 <?php endif; ?>
                              </tbody>
                            </table>

                            <?php echo e($companies->links()); ?>

                          </div>
                          <div class="col-md-4"></div>
                </div>
            </div>
        </div>
    </div>
</div>
 
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
    $('#delete').click(function(){
    location.href = url

    })
  })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dialerapp_backend\resources\views/company/index.blade.php ENDPATH**/ ?>