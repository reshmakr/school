<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/js/bootstrap4-toggle.min.js"></script>
<div class="container">
   <div class="row profile">
      <div class="col-md-12">
         <?php if(Session::has('success_msg')): ?>
         <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
         <?php endif; ?>
         <?php if(Session::has('error_msg')): ?>
         <div class="alert alert-danger"><?php echo e(Session::get('error_msg')); ?></div>
         <?php endif; ?>
         <?php if($errors->any()): ?>
         <div class="alert alert-danger">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
         <?php endif; ?>
         <div class="panel panel-default">
            <div class="panel-heading">
               </br>
               </br>
            </div>
            <div class="panel-body">
               <?php if(session('status')): ?>
               <div class="alert alert-success">
                  <?php echo e(session('status')); ?>

               </div>
               <?php endif; ?>
               <div class="bd-example bd-example-tabs">
                  <div class="row">
                     <div class="col-4">
                        <div class="space_50"></div>
                        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                           <a class="nav-link active show" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="true">Company Info</a>
                           <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Dial Tree</a>
                        </div>
                     </div>
                     <div class="col-7">
                        <div class="tab-content" id="v-pills-tabContent">
                           <div class="tab-pane fade active show" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                              <div class="text-center">
                                 <h3>Add Company</h3>
                              </div>
                              <form method="POST" action="<?php echo e(route('company.store')); ?>" enctype="multipart/form-data">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group">
                                    <label for="inputEmail4" class="required">Company Name</label>
                                    <input type="text" class="form-control" id="inputEmail4" placeholder="Company Name" name="name" value="<?php echo e(old('name')); ?>">
                                 </div>
                                 <div class="">
                                    <label for="inputEmail4" class="required">Company phone Numbers #</label>
                                 </div>
                                 <div class="form-row">
                                    <?php if(old('company_phone_numbers')): ?>
                                    <?php $__currentLoopData = old('company_phone_numbers'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone_number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group col-md-8">
                                       <div>
                                          <input type='tel' class='form-control company_phone_number' id='inputEmail4' placeholder='Company phone Numbers #' name='company_phone_numbers[]'value="<?php echo e(old('company_phone_numbers')[$loop->index]); ?>" maxlength="10" />
                                       </div>
                                    </div>
                                    <div class="form-group col-md-4 tn-buttons">
                                       <button type="button" class="mb-xs mr-xs btn btn-info addmore"><i class="fa fa-plus"></i></button>
                                       <?php if($loop->index >0): ?>
                                       <button type="button" class="mb-xs mr-xs btn btn-info removemore"><i class="fa fa-remove"></i></button>
                                       <?php endif; ?>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <div class="form-group col-md-8">
                                       <div>
                                          <input type='tel' class='form-control company_phone_number' id='inputEmail4' placeholder='Company phone Numbers #' name='company_phone_numbers[]' value="" maxlength="10">
                                          <?php if ($errors->has('phone_numbers')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_numbers'); ?>
                                          <div style="color:red"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                       </div>
                                    </div>
                                    <div class="form-group col-md-4 tn-buttons">
                                       <button type="button" class="mb-xs mr-xs btn btn-info addmore"><i class="fa fa-plus"></i></button>
                                    </div>
                                    <?php endif; ?>
                                 </div>
                                 <div  id="packagingappendhere">
                                    <!-- clone content-->
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress">Address 1</label>
                                    <input type="text" class="form-control" id="inputAddress" placeholder="Address 1" name="company_address1"  value="<?php echo e(old('company_address1')); ?>">
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress2">Address 2</label>
                                    <input type="text" class="form-control" name="company_address2" id="inputAddress2" placeholder="Address 2"  value="<?php echo e(old('company_address2')); ?>">
                                 </div>
                                 <div class="form-row">
                                    <div class="form-group col-md-3">
                                       <label for="inputCity">City</label>
                                       <input name="city" type="text" class="form-control" id="inputCity"  value="<?php echo e(old('city')); ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                       <label for="inputState">State</label>
                                       <input name="state"  value="<?php echo e(old('state')); ?>" type="text" class="form-control" id="inputCity">
                                       <!-- <select id="inputState"name="state"  class="form-control">
                                          <option selected>Choose...</option>
                                          <option>...</option>
                                          </select> -->
                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="inputZip">Zip Code</label>
                                       <input name="zipcode" value="<?php echo e(old('zipcode')); ?>"type="text" class="form-control" id="inputZip">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="inputZip">Website</label>
                                    <input name="website" value="<?php echo e(old('website')); ?>" type="text" class="form-control" id="inputWebsite">
                                 </div>
                                 <div class="form-row">
                                    <div class="form-group col-md-6">
                                       <label>Logo</label>
                                       <div class="input-group">
                                          <span class="input-group-btn">
                                          <span class="btn btn-default btn-file">
                                          Browse… <input  value="<?php echo e(old('company_logo')); ?>" type="file" id="imgInp" name="company_logo">
                                          </span>
                                          </span>
                                          <input type="text" class="form-control" readonly>
                                       </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                       <img id='img-upload'/>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="InputcompanyHours">Hours</label>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Monday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="monday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('monday.from_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="monday[to_time]" value="<?php echo e(old('monday.to_time')); ?>" type="text" class="form-control to_time" placeholder="17:00" autocomplete="off">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Tuesday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="tuesday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('tuesday.from_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="tuesday[to_time]" type="text" class="form-control to_time" placeholder="17:00" autocomplete="off" value="<?php echo e(old('tuesday.to_time')); ?>">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Wednesday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="wednesday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('wednesday.from_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="wednesday[to_time]" type="text" class="form-control to_time" placeholder="17:00" autocomplete="off" value="<?php echo e(old('wednesday.to_time')); ?>">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm  col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Thursday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="thursday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('thursday.from_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="thursday[to_time]" type="text" class="form-control to_time" placeholder="17:00" autocomplete="off" value="<?php echo e(old('thursday.to_time')); ?>">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Friday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="friday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('friday.from_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="friday[to_time]" type="text" class="form-control to_time" placeholder="17:00" autocomplete="off" value="<?php echo e(old('friday.to_time')); ?>">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Saturday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="saturday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('saturday.to_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="saturday[to_time]" type="text" class="form-control to_time" value="<?php echo e(old('saturday.to_time')); ?>" placeholder="17:00" autocomplete="off">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="company_hours">
                                       <div class="form-row">
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                   <input type="checkbox" aria-label="Checkbox for following text input">
                                                </div>
                                             </div>
                                             <input type="text" readonly value="Sunday" class="form-control" aria-label="Text input with checkbox">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">From</span>
                                             </div>
                                             <input id="timeWithDuration" type="text" class="form-control ui-timepicker-input from_time" name="sunday[from_time]" placeholder="09:00" autocomplete="off" value="<?php echo e(old('sunday.to_time')); ?>">
                                          </div>
                                          <div class="form-group input-group input-group-sm col-md-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">To</span>
                                             </div>
                                             <input id="duration" name="sunday[to_time]" type="text" class="form-control to_time" value="<?php echo e(old('sunday.to_time')); ?>" placeholder="17:00" autocomplete="off">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress2">Social Media Links</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="fa fa-facebook fa-lg" aria-hidden="true"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Facebook" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('facebook_url')); ?>" name="facebook_url">
                                    </div>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="fa fa-instagram fa-lg" aria-hidden="true"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Instagram" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('instagram_url')); ?>" name="instagram_url">
                                    </div>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="fa fa-yelp fa-lg" aria-hidden="true"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Yelp" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('yelp_url')); ?>" name="yelp_url">
                                    </div>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="fa fa-twitter fa-lg" aria-hidden="true"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Twitter" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('twitter_url')); ?>" name="twitter_url">
                                    </div>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="fa fa-pinterest fa-lg" aria-hidden="true"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Pinterest" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('pinterest_url')); ?>" name="pinterest_url">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress2">Contact Name</label>
                                    <input name="contact_name" value="<?php echo e(old('contact_name')); ?>"  type="text" class="form-control" id="inputAddress2" placeholder="Contact Name">
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress2">Contact Phone</label>
                                    <input name="contact_phone" value="<?php echo e(old('contact_phone')); ?>" type="text" class="form-control" id="inputAddress2" placeholder="Contact Phone">
                                 </div>
                                 <div class="form-group">
                                    <label for="inputAddress2">Contact Email</label>
                                    <input type="text" name="contact_email" value="<?php echo e(old('contact_email')); ?>" class="form-control" id="inputAddress2" placeholder="Contact Email">
                                 </div>
                                 <button type="submit" class="btn btn-primary">Save</button>
                              </form>
                           </div>
                           <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                              <p>tree</p>
<input type="checkbox" checked data-toggle="toggle" data-onstyle="primary"data-size="mini">
<input type="checkbox" checked data-toggle="toggle" data-onstyle="success" data-size="mini">
<input type="checkbox" checked data-toggle="toggle" data-onstyle="info">
<input type="checkbox" checked data-toggle="toggle" data-onstyle="warning">
<input type="checkbox" checked data-toggle="toggle" data-onstyle="danger">
<input type="checkbox" checked data-toggle="toggle" data-onstyle="default">
								<script>
								  $(function() {
								    $('#toggle-two').bootstrapToggle({
								      on: 'Enabled',
								      off: 'Disabled'
								    });
								  })
								</script>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   //jquery
   $(document).on('click', '.addmore', function (ev) {
   	//var $clone = $(this).parent().parent().clone(true).val("");
   	var $clone = $(this).parent().parent().clone(true).val("");
   	console.log($clone);
   	var $newbuttons = "<button type='button' class='mb-xs mr-xs btn btn-info addmore'><i class='fa fa-plus'></i></button> <button type='button' class='mb-xs mr-xs btn btn-info removemore'><i class='fa fa-remove'></i></button>";
   	$clone.find('.company_phone_number').val('');
   	$clone.find('.tn-buttons').html($newbuttons).end().appendTo($('#packagingappendhere'));
   });
   
   $(document).on('click', '.removemore', function () {
   	$(this).parent().parent().remove();
   });
   
   $(function() {
    
   
       $(".company_hours").each(function() {
           var $duration =  $(this).find('.to_time');
           var $timeWithDuration = $(this).find('.from_time');
           $timeWithDuration.timepicker({ 'scrollDefaultNow': true,'timeFormat': 'H:i' })  .on('changeTime', function() {  
                 var from_time = $(this).closest('.from_time').val(); console.log(from_time);
                 if ($duration.hasClass('ui-timepicker-input')) {
                   $duration.timepicker('remove');
                     $duration.val('');
                 }
                 $duration.timepicker({  
                   'lang':'decimal',
                   'timeFormat': 'H:i',
                     'minTime': from_time,  
                     'maxTime': '23.30',  
                     //'showDuration': true ,
   
                 });  
             });
       });
   
   });
   $(document).ready( function() {
       	$(document).on('change', '.btn-file :file', function() {
   		var input = $(this),
   			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
   		input.trigger('fileselect', [label]);
   		});
   
   		$('.btn-file :file').on('fileselect', function(event, label) {
   		    
   		    var input = $(this).parents('.input-group').find(':text'),
   		        log = label;
   		    
   		    if( input.length ) {
   		        input.val(log);
   		    } else {
   		        if( log ) alert(log);
   		    }
   	    
   		});
   		function readURL(input) {
   		    if (input.files && input.files[0]) {
   		        var reader = new FileReader();
   		        
   		        reader.onload = function (e) {
   		            $('#img-upload').attr('src', e.target.result);
   		        }
   		        
   		        reader.readAsDataURL(input.files[0]);
   		    }
   		}
   
   		$("#imgInp").change(function(){
   		    readURL(this);
   		}); 	
   	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dialerapp_backend\resources\views/company/create.blade.php ENDPATH**/ ?>