<link href="/dist/modules/core/common/img/favicon.ico" rel="shortcut icon">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i" rel="stylesheet">


    <!-- VENDORS -->
    <!-- v2.0.0 -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/vendors/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/vendors/font-icomoon/style.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/vendors/font-awesome/css/font-awesome.min.css'); ?>">
    <script src="<?php echo asset('/dist/vendors/jquery//dist/jquery.min.js'); ?>"></script>
    <script src="<?php echo asset('/dist/vendors/popper.js//dist/umd/popper.js'); ?>"></script>
    <script src="<?php echo asset('/dist/vendors/jquery-ui/jquery-ui.min.js'); ?>"></script>
    <script src="<?php echo asset('/dist/vendors/bootstrap/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo asset('/dist/vendors/jquery-mousewheel/jquery.mousewheel.min.js'); ?>"></script>
    
    <script src="<?php echo asset('/dist/vendors/html5-form-validation//dist/jquery.validation.min.js'); ?>"></script>
    <script src="<?php echo asset('/dist/vendors/bootstrap-show-password/bootstrap-show-password.min.js'); ?>"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/menu-left/common/menu-left.cleanui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/menu-right/common/menu-right.cleanui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/top-bar/common/top-bar.cleanui.css'); ?>">
     <script src="<?php echo asset('/dist/modules/menu-left/common/menu-left.cleanui.js'); ?>"></script>
    <script src="<?php echo asset('/dist/modules/menu-right/common/menu-right.cleanui.js'); ?>"></script>
    <!-- CLEAN UI ADMIN TEMPLATE MODULES-->
    <!-- v2.0.0 -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/core/common/core.cleanui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/vendors/common/vendors.cleanui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/footer/common/footer.cleanui.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('/dist/modules/pages/common/pages.cleanui.css'); ?>">
<?php /**PATH D:\xampp\htdocs\dialerapp_backend\resources\views/components/header.blade.php ENDPATH**/ ?>