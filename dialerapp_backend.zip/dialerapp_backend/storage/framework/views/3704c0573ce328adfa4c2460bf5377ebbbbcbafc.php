<body class="cat__config--horizontal cat__menu-left--colorful cat__config--superclean">
<?php /**PATH D:\xampp\htdocs\dialerapp_backend\resources\views/components/mainmenu.blade.php ENDPATH**/ ?>