<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts.home');
});



Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});

Auth::routes();

Route::get('/sendmail','SendMail@index');
Route::post('/sendmail','SendMail@sendEmail');

Route::get('/home', 'HomeController@index')->name('home');
Route::group(['middleware' => 'App\Http\Middleware\TeacherMiddleware'], function()
{
	Route::get('/classrooms/','ClassroomController@index')->name('classroom.index');

Route::get('/classroom/create','ClassroomController@create');
Route::post('/classroom/store','ClassroomController@store');
// Route::get('/classroom/{id}','ClassroomController@show');
Route::get('/classroom/edit/{id}', 'ClassroomController@edit')->name('classroom.edit');
Route::post('/classroom/update/{id}', 'ClassroomController@update')->name('classroom.update');
Route::get('/classroom/delete/{id}','ClassroomController@destroy');


Route::get('/classroom/{id}','StudentController@index')->name('student.index');

Route::get('/classroom/{id}/student/create','StudentController@create')->name('student.create');
Route::get('/student/{student}/gallery','StudentController@show')->name('student.show');
Route::get('/student/edit/{id}','StudentController@edit')->name('student.edit');
Route::post('/classroom/{id}/student/store','StudentController@store')->name('student.store');
Route::post('/student/update/{id}','StudentController@update')->name('student.update');
Route::get('/student/delete/{id}','StudentController@destroy')->name('student.delete');


Route::get('/student/gallery/delete/{id}','StudentController@destroy1')->name('gallery.delete');


Route::get('/student/{id}/gallery/create','StudentController@create_gallery')->name('gallery.create');
Route::post('/student/{id}/gallery/store','StudentController@store_gallery')->name('gallery.store');


});
Route::get('/student/{id}/gallery','StudentController@gallery')->name('student.gallery');
Route::get('/student/{id}/invite','StudentController@invite')->name('student.invite');
Route::post('/student/{id}/invite','StudentController@addParent')->name('student.addParent');
Route::get('/parent/token/{token}','ParentController@token')->name('parent.token');
Route::get('/parent/','ParentController@index')->name('parent.index');
Route::get('/parent/{student}/gallery','ParentController@show')->name('parent.gallery');
Route::post('/parent/password/confirm','ParentController@confirmPassword')->name('parent.confirm');
Route::post('/parent/password/enter','ParentController@enterPassword')->name('parent.enter');

Route::get('/password/change','ChangePasswordController@create');
Route::post('/password/change','ChangePasswordController@store')->name('change.password');
Route::get('/profile/{id}/edit','ProfileController@edit')->name('profile.edit');
Route::post('/profile/{id}/edit','ProfileController@update')->name('profile.update');
