<?php use \App\Gallery; ?>
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
               </br>
              </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"> Student</th>
      <th scope="col">Photos</th>
      
    </tr>
  </thead>
  <tbody>
   <?php if($studentDetails){ ?>
    @foreach($studentDetails as $key)
    <tr>
      <th scope="row">{{$loop->index+1}}</th>
      <td style="font-weight: bold;font-size: 1.5rem">{{$key->student->first_name}} {{$key->student->last_name}}</td>
      <td><?php $count = Gallery::where('student_id','=',$key->student->id)->count();
      echo $count;?></td>
     <td><a href="{{ route('parent.gallery', $key->student->id) }}" class="btn btn-sm  btn-success">View Gallery</a></td>
    </tr>

    @endforeach
   <?php }else{ ?>
   <tr>
      <th scope="row"></th>
      <td style="font-weight: bold;font-size: 1.5rem"></td>
      <td>No results found</td>
     <td></td>
    </tr>
   <?php } ?>
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


@endsection
