@extends('layouts.app')
@section('style')

 <link rel="stylesheet" type="text/css" href="http://schoolpics.co/public/css/jquery.fancybox.min.css">

 @endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
          

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                 <div class="row">
                  @if(count($galleries)==0)
                  <div class="alert alert-warning">
            <strong>Sorry!</strong>Your child’s teacher has not yet shared any school pics. Please check back regularly for updates
         </div>
                  @else
                  @foreach($galleries as $gallery)

                         <div class="col-sm-4 col-md-3 col-lg-3 p-gallery-img">
                          <a href="{{ asset('public'.$gallery->image) }}" data-fancybox data-caption="{{$gallery->image_description}}">
  <img src="<?php echo url('public'.$gallery->thumbnail);?>" alt="" class="img-thumbnail" style="width: 200px;height: 200px"/>
</a>
                        
                        </div>
              @endforeach
             
              @endif
                 

                

                          

                       
                      


                </div>
            </div>
        </div>
    </div>

                        

                      </div>
</div>

@section('script')
<script type="text/javascript" src="http://schoolpics.co/public/js/jquery.fancybox.min.js"></script>
<style type="text/css">
  .fancybox-button.fancybox-button--share {
  display:none !important;
   }

</style>
@endsection
@endsection