<!DOCTYPE html>
<?php use \App\ParentDetail; ?>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="icon" href="{{url('public/favicon.ico')}}">
    <title>{{ config('app.name', 'School Pics') }}</title>

    <!-- Styles -->
    <link href="{{ asset('public/css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    @yield('style')
<style>
.navbar li a{
    font-weight: 700;
}
.navbar li:hover{
    background: #ff4376;
    color:#fff;
}
.navbar li a:hover{
    background: #ff4376;
    color:#fff !important;
}
.navbar-default .navbar-nav>.open>a, .navbar-default .navbar-nav>.open>a:focus, .navbar-default .navbar-nav>.open>a:hover{
   background: #ff4376;
    color:#fff; 
}

.btn-pink{
    color: #fff;
    background-color: #ff4376;
    border-color: #DF144B;
}

.btn-pink.active, .btn-pink:active, .btn-pink:hover, .open>.btn-pink.dropdown-toggle{
    color: #fff;
    background-color: #DF144B;
    border-color: #ff4376;

}
.btn-danger {
    background-color: #dd4b39;
    border-color: #d73925;
}
.btn-danger:hover, .btn-danger:active, .btn-danger.hover {
    background-color: #d73925 !important;
    border-color: #d73925 !important;
}
.space_10{
    margin-top:10px;
}
</style>
</head>
<body style="">
    <div id="app">

        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    @if(!Auth::guest() && Auth::user()->role_id==1)  
                        <a class="navbar-brand" href="{{ route('classroom.index') }}">
                            <img class="masthead-brand" src="{{url('/public/images/test.png')}}" style="width: 35%;display: block;">
                        </a>
                    @else
                     <a class="navbar-brand" href="{{ route('parent.index') }}">
                        <img class="masthead-brand" src="{{url('/public/images/test.png')}}" style="width: 35%;display: block;">
                    </a>
                    @endif


                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                    </br>
     
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">

                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">Login</a></li>
                        @else

                           <!-- @if(Auth::user()->role_id==1)
                                <li><a href="{{ route('classroom.index') }}">Classrooms</a></li>
                                <li><a href="#">Profile</a></li>
                            @endif-->
                            @if(Auth::user()->role_id==1)

                                <li><a href="{{ route('classroom.index') }}">Back</a></li>
                                <?php $ChildrenCount = ParentDetail::where('email','=',Auth::user()->email)->count();
                                if($ChildrenCount >= 1){?>
                                    <li><a href="{{ route('parent.index') }}">My Children</a></li>
                                <?php } ?>
                           
                            @else
                                <li><a href="{{ route('parent.index') }}">Back</a></li>
                          
                             @endif
                                
                           
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">{{Auth::user()->first_name}} {{Auth::user()->last_name}}
                                <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                     @if(Auth::user()->role_id==1)
                                <li><a href="{{route('profile.edit',['id'=>Auth::user()->id])}}">Edit Profile</a></li>
                                @endif
                                <li><a href="{{url('/password/change')}}">Reset password</a></li>
                                
                                <li> <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>
                                         <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                          
                                        <!-- <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a> -->

                                       
                          <!--  <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->first_name }} {{ Auth::user()->last_name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>-->
                                </ul>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        @yield('content')
    </div>

    <!-- Scripts -->

    <script src="{{ asset('public/js/app.js') }}"></script>
    @yield('script')
</body>
</html>
