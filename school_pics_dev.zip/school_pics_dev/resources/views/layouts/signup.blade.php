

<!-- Modal -->
<div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="signupModalLongTitle" style="text-align:center;color: red;text-shadow: none;font-size: 15px;" >Register</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="signupForm">
          <div class="form-group">
            <input type="text" class="form-control" id="first_name" aria-describedby="first_nameHelp" placeholder="Enter First Name" name="first_name" style="padding: 3px 15px">
            <span id="first_name_error" style="color: red"></span>
         </div>

           <div class="form-group">
            <input type="text" class="form-control" id="last_name" aria-describedby="last_nameHelp" placeholder="Enter Last Name" name="last_name" style="padding: 3px 15px">
            

         </div>

  <div class="form-group">
    
    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email" style="padding: 3px 15px">
            <span id="email_error" style="color: red" ></span>
   
  </div>
 <div class="form-group">
       <select name="role_id" class="form-control" id="role_id" onchange="getAccountType(this);" aria-describedby="roleHelp" style="padding: 3px 15px" >
          <option value="" selected disabled style=" width:1px;">Select Account Type</option>
          <option value="1">Teacher</option>
          <option value="3">Parent</option>
       </select>
       <span id="role_error" style="color: red"></span>
  </div>
  <div id='role_type_display' style="display:none">
    <div class="form-group">
         <input type="text" class="form-control" id="school_name" aria-describedby="school_nameHelp" placeholder="Enter School Name" name="school_name" style="padding: 3px 15px ;">
    </div>

    <div class="form-group">
         <input type ="text" class="form-control" id="school_address" aria-describedby="school_addressHelp" placeholder="Enter School Zip Code" name="school_address" style="padding: 3px 15px">
    </div>
  </div>
  <div class="form-group">
    <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" style="padding: 3px 15px">
            <span id="password_error" style="color: red"></span>

  </div>

    <div class="form-group">
    <input type="password" class="form-control" id="password2" placeholder="Confirm password" name="password_confirmation" style="padding: 3px 15px">
  </div>

  <div align="left">
   
 <p align="justify" style=" font-size: 9px;color:#777;font-family: Segoe UI;text-decoration:none;text-shadow: 0px 0px #000000;"> 
  By clicking "Sign Up" below, you electronically agree to our <a href="#" style="color:#0069d9">Terms of Service </a>and <a href="#" style="color:#0069d9">Privacy Policy</a>;.
  you acknowledge receipt of our Terms,and you agree to receive notices and disclosures from us electronically, 
  including any updates of these Terms.</p>

</div>

 <button type="submit" class="btn btn-primary btn-block" id="signupSubmit" style="padding: 3px 15px">Sign Up</button>
  </div>
 
  <div class="loader" style="display: none"></div>
</form>
      </div>
      
    </div>
  </div>
</div>
