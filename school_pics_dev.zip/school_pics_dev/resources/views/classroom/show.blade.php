@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                {{$classroom->name}}
                <a href="http://schoolpics.co/classroom/{{$classroom->id}}/student/create" style="float: right;">+Add Student</a>
            </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Student Name</th>
      <th scope="col">Student Photos</th>
      
    </tr>
  </thead>
  <tbody>

   
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


@endsection
