@extends('layouts.app')

@section('content')
<style>
/***
User Profile Sidebar by @keenthemes
A component of Metronic Theme - #1 Selling Bootstrap 3 Admin Theme in Themeforest: http://j.mp/metronictheme
Licensed under MIT
***/

body {
  background: #F1F3FA;
}

/* Profile container */
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 20px;
  background: #fff;
  min-height: 460px;
}
</style>
 <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        
        <div class="modal-body">
          <p>Confirm delete?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
<div class="container">
  
    <div class="row profile">
      
    <!-- <div class="col-md-2" style="background:#f5f8fa;">
      <div class="profile-sidebar" style="border-radius:4px; margin-top:15px;">
        
        <div class="profile-userpic">
          <img src="http://localhost/school_pics_dev/public/images/user_image.png" class="img-responsive center-block" alt="" width="50%">
        </div>

        <div class="space_10"></div>
        <div class="profile-usertitle">
          <div class="profile-usertitle-name center-block" style="text-align:center;">
             {{ Auth::user()->first_name }} {{ Auth::user()->last_name }} 
          </div>
        </div>
        <div class="profile-usermenu">
          <ul class="nav">
            
            <li>
              <a href="#">
              Account Settings </a>
            </li>
            <li>
              <a href="#">
              Help </a>
            </li>
          </ul>
        </div>
        
      </div>
    </div> -->

        <div class="col-md-8 col-md-offset-2">
           @if(Session::has('success_msg'))
        <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
            <div class="panel panel-default">
                <div class="panel-heading">
                {{ Auth::user()->first_name }}'s Classrooms
                <a href="{{ action('ClassroomController@create') }}" class="btn btn-pink" style="float: right;padding:5px 10px; "><span class="glyphicon glyphicon-plus"></span>Add Classroom</a>
 </br>
              </br>
            </div>
                <div class="panel-body">

                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Classroom</th>
      <th scope="col">#Students</th>
      <th > </th>
    </tr>
  </thead>
  <tbody>
     @if(count($classrooms)==0)
        <div class="alert alert-warning">
            <strong>Sorry!</strong> No Classrooms Found,Add Classrooms
         </div> 
    @else
    @foreach($classrooms as $classroom)
     <tr>
      <th scope="row">{{$loop->index+1}}</th>
      <td><a href="{{ url('classroom/'.$classroom->id)}}">{{$classroom->name}}</a></td>
      <td>{{ $classroom->students_count }}</td>
      <td class="class-room-btn">
         <a href="{{ url('classroom/'.$classroom->id)}}" style="font-size: 1.2rem;padding: 4px 4px; background: #746e90;border-color:#746e90 " class="btn btn-primary" > View Students</a>
        <a href="{{ url('classroom/edit/'.$classroom->id)}}" style="font-size: 1.2rem;padding: 4px 17px; background: #20895E;border-color:#20895E " class="btn btn-primary" > Edit</a>
     <button class="btn btn-primary delete" style="font-size: 1.2rem;padding: 4px 10px; background: #d73925;border-color: #d73925" data-toggle="modal" data-target="#deleteModal"> Delete
         <input type="hidden" name="" value="{{ url('classroom/delete/'.$classroom->id)}}" class="delete_url"> 
      </button>
        
      </td>
     
    </tr>

    @endforeach
     @endif
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>
 
@section('script')
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
    $('#delete').click(function(){
    location.href = url

    })
  })
</script>
@endsection
@endsection
