@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
            @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Add A New Classroom
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ action('ClassroomController@store') }}">
                    	{{csrf_field()}}
					  <div class="form-group">
					    <label for="name">Classroom name</label>
					    <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Classroom name" name="name">
					   
					  </div>
                      <table align="right">
					<tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Submit</button></td>
                     <td> <a href="{{route('classroom.index')}}" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px">Cancel</a></td></tr>
                  </table>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
@endsection