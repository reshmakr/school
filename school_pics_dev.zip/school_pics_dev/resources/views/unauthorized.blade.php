@extends('layouts.app')
@section('content')
  <div class="col-md-12">
<div class="alert alert-success">
<div class='title m-b-md'>
You cannot access this page! This is for only '{{$role}}'
</div>
</div>
</div>
@endsection