@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                Dashboard
                <a href="/classroom/create" style="float: right;">+Add Classroom</a>
            </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Classroom Name</th>
      <th scope="col">Students</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td><a href="#" style="font-size: 2rem"><i class="fa fa-edit"></i></a></td>
      <td><a href="#" style="color: red;font-size: 2rem"><i class="fa fa-trash"></i></a></td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td><a href="#" style="font-size: 2rem"><i class="fa fa-edit"></i></a></td>
      <td><a href="#" style="color: red;font-size: 2rem"><i class="fa fa-trash"></i></a></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td><a href="#" style="font-size: 2rem"><i class="fa fa-edit"></i></a></td>
      <td><a href="#" style="color: red;font-size: 2rem"><i class="fa fa-trash"></i></a></td>
    </tr>
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


@endsection
