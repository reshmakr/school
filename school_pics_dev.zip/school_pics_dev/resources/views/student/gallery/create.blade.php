@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Add A New Photo
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ route('gallery.store', [$student->id]) }}" enctype="multipart/form-data">
                    	{{csrf_field()}}
                        <img src="{{url('/public/images/add.png')}}" style="margin: auto;display: block;width: 350px" id="image_preview">
                        <br>
                        <!--
					  <div class="form-group">
					    <label for="image_name">Image Name</label>
					    <input type="text" class="form-control" id="image_name" aria-describedby="nameHelp" placeholder="Enter Image Name" name="image_name">
					    @if ($errors->has('image_name'))
                                    <span class="help-block">
                                        <strong style="color:red">{{ $errors->first('image_name') }}</strong>
                                    </span>
                                @endif
					  </div>
-->
                       <div class="form-group">
                        <label for="image_description">Image Description</label>
                        <input type="text" class="form-control" id="image_description" aria-describedby="nameHelp" placeholder="Enter Image Description(optional)" name="image_description">
                       
                      </div>
                     
                     <div class="form-group">
                         <input type="file" class="form-control" accept="image/*" id="upload_image" name="upload_image">
                           @if ($errors->has('upload_image'))
                                    <span class="help-block">
                                        <strong style="color:red">{{ $errors->first('upload_image') }}</strong>
                                    </span>
                                @endif
                     </div>
					  
					   <table align="right">
<tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Upload</button></td>
                     <td> <a href="{{route('student.index', [$student->classroom_id])}}" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px;border-color: #FF4376">Cancel</a></td></tr>
                  </table>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
@section('script')
<script type="text/javascript">
    $('#upload_image').change(function(e){
       
       $('#image_preview').attr('src',URL.createObjectURL(e.target.files[0]))
    })
</script>
@endsection
@endsection