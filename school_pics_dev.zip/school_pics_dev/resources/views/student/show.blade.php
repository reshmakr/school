@extends('layouts.app')
@section('style')

 <link rel="stylesheet" type="text/css" href="http://schoolpics.co/public/css/jquery.fancybox.min.css">
  
 @endsection

@section('content')
<div class="modal fade" id="deleteModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p>Confirm delete?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>
<div class="container">
    <div class="row">
         
        <div class="col-md-12">
            @if(Session::has('success_msg'))
        <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
         @if(Session::has('msg'))
        <div class="alert alert-success">{{ Session::get('msg') }}</div>
        @endif
            <div class="panel panel-default">
          <div class="panel-heading" style="height: 60px">
             @if (!Auth::guest())
             <table align="right">
                <tr>
                
                   <td>

          <!--  <a href="{{ route('student.index', [$student->classroom_id]) }}" style="float: right;padding: 5px 20px;margin-right: 5px;" class="btn btn-primary">Back</a>-->
              </td>
                  <td>
            <a href="{{ route('gallery.create', [$student->id]) }}" style="float: right;padding: 5px 10px;" class="btn btn-pink">+Add Photo</a>
              </td>
          </tr>
          </table>

           @endif
          </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                 <div class="row">
                   @if(count($galleries)==0)
        <div class="alert alert-warning">
            <strong>Sorry!</strong> No Images Found,Add Images
         </div> 
    
    @else
                  @foreach($galleries as $gallery)
                         <div class="col-sm-4 col-md-3 col-lg-3 p-gallery-img ">
                          
                          <a href="{{ asset('public'.$gallery->image) }}" data-fancybox data-caption="{{$gallery->image_description}}">
                          <img src="<?php echo url('public'.$gallery->thumbnail);?>" alt="" class="img-thumbnail" style="width: 200px;height: 200px"/>
                         <a href="{{ route('gallery.delete', $gallery->id) }}" data-toggle="modal" data-target="#deleteModal" > <span class=" align-middle btn-sm btn btn-danger"> Delete</span></a>
                          </a>
                          <a href="{{ asset('public'.$gallery->image) }}" data-fancybox data-caption="{{$gallery->image_description}}" class="btn btn-sm btn-success"> Enlarge</a>
                        </div>

              @endforeach
                  @endif

                

                          

                       
                      


                </div>
            </div>
        </div>
    </div>

                        

                      </div>
</div>

@section('script')

<script type="text/javascript" src="http://schoolpics.co/public/js/jquery.fancybox.min.js"></script>
</script> 
<style type="text/css">
  .fancybox-button.fancybox-button--share {
  display:none !important;
   }

</style>
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
   
  })
 $('#delete').click(function(){
    location.reload();
  })
</script> 

@endsection
@endsection