@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif

        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Edit Student
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form method="POST" action="{{ route('student.update', $student->id) }}">
                        {{csrf_field()}}
                        <h2>Student Details</h2>
                      <div class="form-group">
                        <label for="name">First Name</label>
                        <input type="text" class="form-control" id="first_name" aria-describedby="nameHelp" placeholder="Enter First name" name="first_name" value="{{ $student->first_name}}">
                       
                      </div>

                       <div class="form-group">
                        <label for="name">Last Name</label>
                        <input type="text" class="form-control" id="last_name" aria-describedby="nameHelp" placeholder="Enter Last name" name="last_name"value="{{ $student->last_name}}">
                       
                      </div>
                    <?php if(isset($student->parentDetails)) { ?>
                      <h2>Parent Details</h2>
                       <div class="form-group">
                        <label for="parent_first_name">First Name</label>
                        <input type="text" class="form-control" id="parent_first_name" aria-describedby="nameHelp" placeholder="Enter First name" name="parent_first_name"value="{{ $student->parentDetails->first_name }}">
                       
                      </div>

                    <div class="form-group">
                        <label for="parent_last_name">Last Name</label>
                        <input type="text" class="form-control" id="parent_last_name" aria-describedby="nameHelp" placeholder="Enter Last name" name="parent_last_name" value="{{ $student->parentDetails->last_name }}">
                       
                      </div>

                    <div class="form-group">
                        <label for="parent_email">Email</label>
                        <input type="email" readonly class="form-control" id="parent_email" aria-describedby="nameHelp" placeholder="Enter Email" name="parent_email" value="{{ $student->parentDetails->email}}">
                       
                      </div>

                    <div class="form-group">
                        <label for="parent_email">Relation</label>
                        <input type="text" class="form-control" id="relation" aria-describedby="nameHelp" placeholder="Mom or Dad etc..." name="relation" value="{{ $student->parentDetails->relation}}">
                       
                      </div>
                     <?php } ?>
                        <table align="right">
<tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Submit</button></td>
                     <td> <a href="{{route('student.index', [$student->classroom_id])}}" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px">Cancel</a></td></tr>
                  </table>
                    </form>



                </div>
            </div>
        </div>
    </div>
</div>
@endsection

