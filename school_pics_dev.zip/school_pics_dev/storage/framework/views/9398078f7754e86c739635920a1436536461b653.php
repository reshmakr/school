<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Add A new Photo
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="/student/<?php echo e($student->id); ?>/gallery/store" enctype="multipart/form-data">
                    	<?php echo e(csrf_field()); ?>

                        <img src="http://via.placeholder.com/350x250" style="margin: auto;display: block;width: 350px" id="image_preview">
                        <br>
					  <div class="form-group">
					    <label for="image_name">Image Name</label>
					    <input type="text" class="form-control" id="image_name" aria-describedby="nameHelp" placeholder="Enter Image Name" name="image_name">
					    <?php if($errors->has('image_name')): ?>
                                    <span class="help-block">
                                        <strong style="color:red"><?php echo e($errors->first('image_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
					  </div>

                       <div class="form-group">
                        <label for="image_description">Image Description</label>
                        <input type="text" class="form-control" id="image_description" aria-describedby="nameHelp" placeholder="Enter Image Description" name="image_description">
                       
                      </div>
                     
                     <div class="form-group">
                         <input type="file" class="form-control" accept="image/*" id="upload_image" name="upload_image">
                           <?php if($errors->has('upload_image')): ?>
                                    <span class="help-block">
                                        <strong style="color:red"><?php echo e($errors->first('upload_image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                     </div>
					  
					  <button type="submit" class="btn btn-primary btn-block">Submit</button>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('#upload_image').change(function(e){
       
       $('#image_preview').attr('src',URL.createObjectURL(e.target.files[0]))
    })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>