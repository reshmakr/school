<?php use \App\Gallery; ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
               </br>
              </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"> Student</th>
      <th scope="col">Photos</th>
      
    </tr>
  </thead>
  <tbody>
   <?php if($studentDetails){ ?>
    <?php $__currentLoopData = $studentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->index+1); ?></th>
      <td style="font-weight: bold;font-size: 1.5rem"><?php echo e($key->student->first_name); ?> <?php echo e($key->student->last_name); ?></td>
      <td><?php $count = Gallery::where('student_id','=',$key->student->id)->count();
      echo $count;?></td>
     <td><a href="<?php echo e(route('parent.gallery', $key->student->id)); ?>" class="btn btn-sm  btn-success">View Gallery</a></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php }else{ ?>
   <tr>
      <th scope="row"></th>
      <td style="font-weight: bold;font-size: 1.5rem"></td>
      <td>No results found</td>
     <td></td>
    </tr>
   <?php } ?>
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>