<?php $__env->startSection('content'); ?>
<div class="modal fade" id="deleteModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p>Confirm delete?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="col-md-12"> <?php if(Session::has('success_msg')): ?>
      <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
      <?php endif; ?>
      
      <?php if(Session::has('invite_msg')): ?>
      <div class="alert alert-success"><?php echo e(Session::get('invite_msg')); ?></div>
      <?php endif; ?>
      <div class="panel panel-default">
        <div class="panel-heading"> <?php echo e($classroom->name); ?>

          <table align="right">
            <tr> 
              <!-- <td>
                <a href="<?php echo e(route('classroom.index')); ?>" class="btn btn-primary" style="padding:5px 20px;margin-right: 5px">Back</a>
              </td> -->
              <td><a href="<?php echo e(route('student.create', $classroom->id)); ?>" class="btn btn-pink" style="float: right;padding:5px 10px; "><span class="glyphicon glyphicon-plus"></span>Add Student</a></td>
            </tr>
          </table>
          </br>
          </br>
        </div>
        <div class="panel-body"> <?php if(session('status')): ?>
          <div class="alert alert-success"> <?php echo e(session('status')); ?> </div>
          <?php endif; ?>
          <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col"> Student</th>
                <th scope="col">#Photos</th>
                <th scope="col"></th>
              
              </tr>
            </thead>
            <tbody>
            
            <?php if(count($students)==0): ?>
            <div class="alert alert-warning"> <strong>Sorry!</strong> No Students Found. </div>
            <?php else: ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->index+1); ?></th>
              <td style="font-weight: bold;font-size: 1.5rem"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></td>
              <td><?php echo e($student->galleries_count); ?></td>
              <?php if(\App\Invitation::where('parent_detail_id',\App\ParentDetail::where('student_id',$student->id)->first()['id'])->first()['status']==0): ?>
              <td class="class-room-btn"><a href="<?php echo e(route('student.invite',$student->id)); ?>" class="btn btn-sm  btn-success " style="padding: 5px 15px;background: #D73925;border-color: #D73925" >Invite Parent</a>
              
             <a href="<?php echo e(route('student.edit', $student->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
              <a href="" class="btn btn-sm btn-danger delete" data-toggle="modal" data-target="#deleteModal">Delete
                <input type="hidden" name="" value="<?php echo e(route('student.delete', $student->id)); ?>" class="delete_url">
                </a>
                <a href="<?php echo e(route('student.gallery', $student->id)); ?>" class="btn btn-sm  btn-success">View Gallery</a>
             <a href="<?php echo e(route('gallery.create', [$student->id])); ?>" style="padding: 3px 10px;margin-right: : 35px;background: #746e90; border-color: #746e90" class="btn btn-primary" >+Add Photos</a>
         </td>
              <?php elseif(\App\Invitation::where('parent_detail_id',\App\ParentDetail::where('student_id',$student->id)->first()['id'],'desc')->first()['status']==1): ?>
              <td class="pending class-room-btn" ><a href="<?php echo e(route('student.invite',$student->id)); ?>" class="btn btn-sm  btn-info disabled" style="background: #6B9DBB;border-color: #6B9DBB" >Pending</a>
              
          <a href="<?php echo e(route('student.edit', $student->id)); ?>" class="btn btn-sm btn-primary" >Edit</a>
             <a href="" class="btn btn-sm btn-danger delete" data-toggle="modal" data-target="#deleteModal">Delete
                <input type="hidden" name="" value="<?php echo e(route('student.delete', $student->id)); ?>" class="delete_url">
                </a>
                <a href="<?php echo e(route('student.gallery', $student->id)); ?>" class="btn btn-sm  btn-success">View Gallery</a>
             <a href="<?php echo e(route('gallery.create', [$student->id])); ?>" style="padding: 3px 10px;margin-right: : 35px;background: #746e90; border-color: #746e90" class="btn btn-primary" >+Add Photos</a>
            </td>
              <?php elseif(\App\Invitation::where('parent_detail_id',\App\ParentDetail::where('student_id',$student->id)->first()['id'],'desc')->first()['status']==2): ?>
              <td class="class-room-btn"><i class="fa fa-check" style="color:lightgreen;font-size:24px"></i>
            
             <a href="<?php echo e(route('student.edit', $student->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
              <a href="" class="btn btn-sm btn-danger delete" data-toggle="modal" data-target="#deleteModal">Delete
                <input type="hidden" name="" value="<?php echo e(route('student.delete', $student->id)); ?>" class="delete_url">
                </a>
             <a href="<?php echo e(route('student.gallery', $student->id)); ?>" class="btn btn-sm  btn-success">View Gallery</a>
             <a href="<?php echo e(route('gallery.create', [$student->id])); ?>" style="padding: 3px 10px;margin-right: : 35px;background: #746e90; border-color: #746e90" class="btn btn-primary" >+Add Photos</a></td>
            </tr>
            <?php endif; ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
              </tbody>
            
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->startSection('script'); ?> 
<script type="text/javascript">
  $('.Pending').mouseover(function(){
    $(this).find('a').html('Invite again')

    $(this).find('a').removeClass('disabled')
      $(this).find('a').removeClass('btn-success')
      $(this).find('a').addClass('btn-danger')


  })

  $('.Pending').mouseleave(function(){
      $(this).find('a').html('pending')
   $(this).find('a').removeClass('btn-danger')

     $(this).find('a').addClass('disabled')
      $(this).find('a').addClass('btn-success')


  })


</script> 
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
    $('#delete').click(function(){
    location.href = url

    })
  })
</script> 
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>