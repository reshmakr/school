<?php $__env->startSection('css'); ?>
<link href="http://35.154.35.78/school_pics/public/css/cover.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
      <header class="masthead mb-auto">
        <div class="inner" style="background-color: #fff;width:200px;height: 200px;border-radius: 50%;position: absolute;top:-15%;left:10%">
          <img class="masthead-brand" src="http://35.154.35.78/school_pics/public/images/test.png" style="width: 50%;margin: 120px 50px;display: block;">
 <!--          <nav class="nav nav-masthead justify-content-center">
            <a class="nav-link" data-toggle="modal" data-target="#signinModal" style="cursor: pointer;">Sign In</a>
            <a class="nav-link" data-toggle="modal" data-target="#signupModal" style="cursor: pointer;">Sign Up</a>
           
          </nav> -->
        </div>
      </header>

      <main role="main" class="inner cover">
        <h1 class="cover-heading">PRIVATE CLASSROOM <span style="display: block;">ALBUMS FOR TEACHERS</span> AND PARENTS</h1>
        <p class="lead">School Pics allows teachers to quickly and securely share image</p>
         
       
          <a class="btn btn-lg btn-danger" style="margin:10px" data-toggle="modal" data-target="#signupModal" style="cursor: pointer;">Signup</a>
        

       
          <a class="btn btn-lg btn-danger" data-toggle="modal" data-target="#signinModal" style="cursor: pointer;">Log In</a>
      </main>

      <footer class="mastfoot mt-auto">
       <!--  <div class="inner">
          <p>Cover template for <a href="https://getbootstrap.com/">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
        </div> -->
      </footer>
    </div>

    <?php echo $__env->make('layouts.signup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="http://localhost/school_pics/public/js/auth.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>