<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Add A New Photo
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('gallery.store', [$student->id])); ?>" enctype="multipart/form-data">
                    	<?php echo e(csrf_field()); ?>

                        <img src="<?php echo e(url('/public/images/add.png')); ?>" style="margin: auto;display: block;width: 350px" id="image_preview">
                        <br>
                        <!--
					  <div class="form-group">
					    <label for="image_name">Image Name</label>
					    <input type="text" class="form-control" id="image_name" aria-describedby="nameHelp" placeholder="Enter Image Name" name="image_name">
					    <?php if($errors->has('image_name')): ?>
                                    <span class="help-block">
                                        <strong style="color:red"><?php echo e($errors->first('image_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
					  </div>
-->
                       <div class="form-group">
                        <label for="image_description">Image Description</label>
                        <input type="text" class="form-control" id="image_description" aria-describedby="nameHelp" placeholder="Enter Image Description(optional)" name="image_description">
                       
                      </div>
                     
                     <div class="form-group">
                         <input type="file" class="form-control" accept="image/*" id="upload_image" name="upload_image">
                           <?php if($errors->has('upload_image')): ?>
                                    <span class="help-block">
                                        <strong style="color:red"><?php echo e($errors->first('upload_image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                     </div>
					  
					   <table align="right">
<tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Upload</button></td>
                     <td> <a href="<?php echo e(route('student.index', [$student->classroom_id])); ?>" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px;border-color: #FF4376">Cancel</a></td></tr>
                  </table>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('#upload_image').change(function(e){
       
       $('#image_preview').attr('src',URL.createObjectURL(e.target.files[0]))
    })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>