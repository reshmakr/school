<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                Dashboard
                <a href="/classroom/<?php echo e($classroom->id); ?>/student/create" style="float: right;">+Add Student</a>
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"> Student</th>
      <th scope="col">Photos</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->index+1); ?></th>
      <td style="font-weight: bold;font-size: 1.5rem"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></td>
      <td>15</td>

      <td><a href="/student/edit/<?php echo e($student->id); ?>" class="btn btn-block btn-primary">Edit</a></td>
      <td><a href="/student/delete/<?php echo e($student->id); ?>" class="btn btn-block btn-danger">Delete</a></td>
        <td><a href="/student/<?php echo e($student->id); ?>/gallery" class="btn btn-block  btn-success">View Gallery</a></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>