<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
    	<?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Edit Classroom
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('classroom.update', $classroom->id)); ?>">
                    	<?php echo e(csrf_field()); ?>

					  <div class="form-group">
					    <label for="name">Classroom name</label>
					    <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Classroom name" name="name" value="<?php echo e($classroom->name); ?>">
					   
					  </div>
					  
					   <table align="right">
                    <tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Submit</button></td>
                     <td> <a href="<?php echo e(route('classroom.index')); ?>" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px">Cancel</a></td></tr>
                  </table>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>