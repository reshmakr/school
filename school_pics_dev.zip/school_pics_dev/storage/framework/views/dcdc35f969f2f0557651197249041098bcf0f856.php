<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
       
            <div class="panel panel-default">
                <div class="panel-heading">Edit profile</div>

                <div class="panel-body">
<form method="POST" action="<?php echo e(route('profile.update',$user->id)); ?>">
    <?php echo e(csrf_field()); ?>

    <?php if($user->role_d!=3): ?>
          <div class="form-group">
            <input type="text" class="form-control" id="first_name" aria-describedby="first_nameHelp" placeholder="Change First Name" name="first_name" value="<?php echo e($user->first_name); ?>">
            <span id="first_name_error" style="color: red"></span>
         </div>

           <div class="form-group">
            <input type="text" class="form-control" id="last_name" aria-describedby="last_nameHelp" placeholder="Change Last Name" name="last_name"  value="<?php echo e($user->last_name); ?>">
            

         </div>

  

  <div class="form-group">
       <input type="text" class="form-control" id="school_name" aria-describedby="school_nameHelp" placeholder="Change School Name" name="school_name"  value="<?php echo e($user->school_name); ?>">
  </div>

    <div class="form-group">
       <textarea class="form-control" id="school_address" aria-describedby="school_addressHelp" placeholder="Change School Address" name="school_address" ><?php echo e($user->school_address); ?></textarea>
  </div>

  

 
  <table align="right">
                    <tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Submit</button></td>
                     <td> <a href="<?php echo e(route('classroom.index')); ?>" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px">Cancel</a></td></tr>
                  </table>
  </div>
 
  <div class="loader" style="display: none"></div>
  <?php else: ?>
  <div class="form-group">
            <input type="text" class="form-control" id="first_name" aria-describedby="first_nameHelp" placeholder="Change First Name" name="first_name" value="<?php echo e($user->first_name); ?>">
            <span id="first_name_error" style="color: red"></span>
         </div>

           <div class="form-group">
            <input type="text" class="form-control" id="last_name" aria-describedby="last_nameHelp" placeholder="Change Last Name" name="last_name"  value="<?php echo e($user->last_name); ?>">
            

         </div>

  

 <table align="right">
                    <tr><td>  <button type="submit" class="btn btn-success btn-block" style="padding:5px 15px;margin-right: 15px;">Submit</button></td>
                     <td> <a href="<?php echo e(route('classroom.index')); ?>" class="btn btn-block btn-pink" style="padding:5px 15px;margin-left: 5px">Cancel</a></td></tr>
                  </table>

  

 
 
  </div>
 
  <div class="loader" style="display: none"></div>
  <?php endif; ?>
</form>

 </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>