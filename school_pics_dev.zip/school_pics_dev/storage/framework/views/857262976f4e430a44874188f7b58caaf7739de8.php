<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                Dashboard
                <a href="/classroom/create" style="float: right;">+Add Classroom</a>
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Classroom Name</th>
      <th scope="col">Students</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->index+1); ?></th>
      <td><a href="/classroom/<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></a></td>
      <td>22</td>
      <td><a href="/classroom/edit/<?php echo e($classroom->id); ?>" style="font-size: 2rem"><i class="fa fa-edit"></i></a></td>
      <td><a href="/classroom/delete/<?php echo e($classroom->id); ?>" style="color: red;font-size: 2rem"><i class="fa fa-trash"></i></a></td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>