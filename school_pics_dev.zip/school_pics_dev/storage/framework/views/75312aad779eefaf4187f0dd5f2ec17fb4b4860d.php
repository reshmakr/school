<?php $__env->startSection('css'); ?>
<link href="<?php echo e(url('public/css/cover.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 offset-md-3" style="background:#fff">
        <?php if(Session::has('change_pwd_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('change_pwd_msg')); ?></div>
        <?php endif; ?>
            <div class="panel panel-default"><br/>
                <div class="panel-heading"><h5 style="color: red;text-shadow: none">Register</h5><br/></div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('parent.enter')); ?>">
                        <?php echo e(csrf_field()); ?>


                      


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control" required disabled value="<?php echo e($parentDetails->email); ?>">
                                <input type="hidden" name="email" value="<?php echo e($parentDetails->email); ?>">
                                <input type="hidden" name="parent_id" value="<?php echo e($parentDetails->id); ?>">
                                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control" name="password" required placeholder="Password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                         <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                           

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">

                            </div>
                        </div>
                        <div class="form-group">
                        <div class="col-md-12">
                         
   
                             <p align="justify" style=" font-size: 11px;color:#777;font-family: Segoe UI;text-decoration:none;text-shadow: 0px 0px #000000;"> 
                              By clicking "Sign Up" below, you electronically agree to our <a href="#" style="color:#0069d9">Terms of Service </a>and <a href="#" style="color:#0069d9">Privacy Policy</a> (the "Terms");
                              you acknowledge receipt of our Terms,and you agree to receive notices and disclosures from us electronically, 
                              including any updates of these Terms.</p>

                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary btn-md">
                                    Sign Up
                                </button>
                                <a href="<?php echo e(URL::to('/#login')); ?>" class="btn btn-success btn-md">
                                    Login
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>