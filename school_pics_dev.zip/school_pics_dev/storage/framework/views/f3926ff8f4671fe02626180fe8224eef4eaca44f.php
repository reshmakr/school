<?php $__env->startSection('style'); ?>

 <link rel="stylesheet" type="text/css" href="http://35.154.35.78/school_pics/public/css/jquery.fancybox.min.css">
  
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="modal fade" id="deleteModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p>Confirm delete?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete">Delete</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>
<div class="container">
    <div class="row">
         
        <div class="col-md-12">
            <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
         <?php if(Session::has('msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
        <?php endif; ?>
            <div class="panel panel-default">
          <div class="panel-heading" style="height: 60px">
             <?php if(!Auth::guest()): ?>
             <table align="right">
                <tr>
                
                   <td>

          <!--  <a href="<?php echo e(route('student.index', [$student->classroom_id])); ?>" style="float: right;padding: 5px 20px;margin-right: 5px;" class="btn btn-primary">Back</a>-->
              </td>
                  <td>
            <a href="<?php echo e(route('gallery.create', [$student->id])); ?>" style="float: right;padding: 5px 10px;" class="btn btn-pink">+Add Photo</a>
              </td>
          </tr>
          </table>

           <?php endif; ?>
          </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                 <div class="row">
                   <?php if(count($galleries)==0): ?>
        <div class="alert alert-warning">
            <strong>Sorry!</strong> No Images Found,Add Images
         </div> 
    
    <?php else: ?>
                  <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="col-sm-4 col-md-3 col-lg-3 p-gallery-img ">
                          
                          <a href="<?php echo e(asset('public'.$gallery->image)); ?>" data-fancybox data-caption="<?php echo e($gallery->image_description); ?>">
                          <img src="<?php echo url('public'.$gallery->thumbnail);?>" alt="" class="img-thumbnail" style="width: 200px;height: 200px"/>
                         <a href="<?php echo e(route('student.delete', $gallery->id)); ?>" data-toggle="modal" data-target="#deleteModal" > <span class=" align-middle btn-sm btn btn-danger"> Delete</span></a>
                          </a>
                          <a href="<?php echo e(asset('public'.$gallery->image)); ?>" data-fancybox data-caption="<?php echo e($gallery->image_description); ?>" class="btn btn-sm btn-success"> view</a>
                        </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                

                          

                       
                      


                </div>
            </div>
        </div>
    </div>

                        

                      </div>
</div>

<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="http://35.154.35.78/school_pics/public/js/jquery.fancybox.min.js"></script>
</script> 
<script type="text/javascript">
  
  $('.delete').click(function(){
    console.log('hello')
    url = $(this).find('input').val();
    
   
  })
 $('#delete').click(function(){
    location.reload();
  })
</script> 

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>