<?php $__env->startSection('style'); ?>

 <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox.min.css">

 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
          <div class="panel-heading" style="height: 60px">
            <a href="/student/<?php echo e($student->id); ?>/gallery/create" style="float: right;" class="btn btn-primary">+add Photo</a>
          </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                 <div class="row">
                  <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <div class="col-md-3 col-lg-3">
                          <a href="<?php echo e($gallery->image); ?>" data-fancybox data-caption="<?php echo e($gallery->image_description); ?>">
  <img src="<?php echo e($gallery->thumbnail); ?>" alt="" class="img-thumbnail" style="width: 200px;height: 200px"/>
</a>
                        
                        </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 

                

                          

                       
                      


                </div>
            </div>
        </div>
    </div>

                        

                      </div>
</div>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="/js/jquery.fancybox.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>