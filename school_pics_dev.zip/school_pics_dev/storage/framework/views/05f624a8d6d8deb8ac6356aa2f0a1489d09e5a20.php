<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                Add A new Classroom
                <!-- <a href="/classroom/create" style="float: right;">+Add Classroom</a> -->
            </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="/classroom/store">
                    	<?php echo e(csrf_field()); ?>

					  <div class="form-group">
					    <label for="name">Classroom name</label>
					    <input type="text" class="form-control" id="name" aria-describedby="nameHelp" placeholder="Enter Classroom name" name="name">
					   
					  </div>
					  
					  <button type="submit" class="btn btn-primary btn-block">Submit</button>
					</form>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>