<?php $__env->startSection('style'); ?>

 <link rel="stylesheet" type="text/css" href="http://35.154.35.78/school_pics/public/css/jquery.fancybox.min.css">

 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
          

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                 <div class="row">
                  <?php if(count($galleries)==0): ?>
                  <div class="alert alert-warning">
            <strong>Sorry!</strong>Your child’s teacher has not yet shared any school pics. Please check back regularly for updates
         </div>
                  <?php else: ?>
                  <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <div class="col-sm-4 col-md-3 col-lg-3 p-gallery-img">
                          <a href="<?php echo e(asset('public'.$gallery->image)); ?>" data-fancybox data-caption="<?php echo e($gallery->image_description); ?>">
  <img src="<?php echo url('public'.$gallery->thumbnail);?>" alt="" class="img-thumbnail" style="width: 200px;height: 200px"/>
</a>
                        
                        </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              <?php endif; ?>
                 

                

                          

                       
                      


                </div>
            </div>
        </div>
    </div>

                        

                      </div>
</div>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="http://35.154.35.78/school_pics/public/js/jquery.fancybox.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>