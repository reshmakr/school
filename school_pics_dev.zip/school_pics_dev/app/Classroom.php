<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classroom extends Model
{
    //
	 protected $fillable = ['name'];
    public function users(){
    	return $this->belongsToMany('App\User');
    }

    public function students(){
    	return $this->hasMany('App\Student');
    }

}
