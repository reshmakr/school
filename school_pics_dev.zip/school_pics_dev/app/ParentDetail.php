<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParentDetail extends Model
{
      public function student()
    {
        return $this->belongsTo('App\Student');
    }
     public function invitations(){
    	return $this->hasMany('App\Invitation');
    }
}
