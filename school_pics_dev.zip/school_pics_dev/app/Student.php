<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    public function parentDetails(){
    	return $this->hasOne('App\ParentDetail');
    }

    public function classrooms(){
    	return $this->belongsTo('App\Classroom');
    }

    public function galleries(){
    	return $this->hasMany('App\Gallery');
    }
}
