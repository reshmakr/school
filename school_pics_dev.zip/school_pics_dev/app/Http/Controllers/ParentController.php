<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth;
use session;
use \App\Invitation;
use \App\ParentDetail;
use \App\Student;
use \App\Gallery;

class ParentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    /*public function __construct()
    {
        $this->middleware('auth');
    }*/

   
    public function index()
    { 
       
       $studentDetails = \App\ParentDetail::where('user_id', \Auth::user()->id)->with('student:id,first_name,last_name,classroom_id')->get();
        
        if(!$studentDetails){
            $studentDetails=array();
        }

        
        return view('parent.index',compact(['studentDetails']));
    }

    public function children()
    { 
       
        $parentDetails = \App\ParentDetail::where('user_id', \Auth::user()->id)->first();
        //var_dump($parentDetails);die();
        $student = \App\Student::find($parentDetails->student_id);
        $galleries = \App\Gallery::all()->where('student_id',$student->id)->sortByDesc('id');
        return view('student.show',compact(['student','galleries']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('classroom.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
        'name' => 'required|unique:classrooms|max:255',
        
    ]);

         $classroom = new \App\Classroom;
         $classroom->name = $request->name;
         $classroom->user_id = \Auth::user()->id;
         $classroom->save();
         
         return redirect('/classrooms');
    }

    public function show($sid)
    {
       
        $student = \App\Student::find($sid);
        $galleries = \App\Gallery::all()->where('student_id',$sid)->sortByDesc('id');
        return view('parent.show',compact(['student','galleries']));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $classroom = \App\Classroom::find($id);
        return view('classroom.edit',compact('classroom'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function update($id, Request $request){
        //validate post data
         $this->validate($request, [
        'name' => 'required|max:255',
        
    ]);
        
        //get post data
        $postData = $request->all();
        
        //update post data
        \App\Classroom::find($id)->update($postData);
        
        //store status message
        \Session::flash('success_msg', 'Classroom updated successfully!');

        return redirect()->route('classroom.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function token($token)
    { 
        
        $invitations = \App\Invitation::where('invitaion_token', $token)->first();
        $token = $invitations->invitaion_token;
        // $invitations->status = 2;
        // $invitations->save();
        $parent_id=$invitations->parent_detail_id;
        $parentDetails=\App\ParentDetail::find($parent_id);
        $checkUser  =\App\User::find($parentDetails->user_id);
        // $student = \App\Student::find($parentDetails->student_id);
        // $galleries = \App\Gallery::all()->where('student_id',$student->id)->sortByDesc('id');
        if (\Auth::check()){
            \Auth::logout();
        }

        if(!$checkUser){
            return view('parent.confirm',compact(['parentDetails','token']));
        }else{
            $invitations = \App\Invitation::where('invitaion_token',$token)->first();
            $invitations->status = 2;
            $invitations->save();

            \Session::flash('success_msg', 'Please Login to continue ...');
             return redirect('/#login');
            //return view('parent.enter',compact(['parentDetails','token']));
        }
        
    }

    public function enterPassword(Request $request){
            $this->validate($request, [
        'email' => 'email',
        'password' => 'required|min:6|confirmed',

        
    ]);
           
            $user = new \App\User;
            $parentDetail = \App\ParentDetail::find($request->parent_id);
            $user->first_name = $parentDetail->first_name;
            $user->last_name = $parentDetail->last_name;
            $user->email = $parentDetail->email;
            $user->password = bcrypt($request->password);
            $user->role_id = 3;

            $user->save();
            $parentDetail->user_id = $user->id;
            $parentDetail->save();

           /// $invitations = \App\Invitation::where('invitaion_token',$request->token);
            //$invitations->status = 2;
            //$invitations->save();

        $student = \App\Student::find($parentDetail->student_id);
        $galleries = \App\Gallery::all()->where('student_id',$student->id)->sortByDesc('id');
        \Auth::loginUsingId($user->user_id, true);
        return redirect()->back();
          
    }


    public function confirmPassword(Request $request){
        $this->validate($request, [
        'password' => 'required|min:6',
        
    ]);
        $invitations = \App\Invitation::where('invitaion_token',$request->token)->first();
            $invitations->status = 2;
            $invitations->save();

            $parent_id=$invitations->parent_detail_id;
        $parentDetails=\App\ParentDetail::find($parent_id);
        $studentDetails = \App\Student::find($parentDetails->student_id);
        // $galleries = \App\Gallery::all()->where('student_id',$studentDetails->id)->sortByDesc('id');
       
     \Auth::loginUsingId($parentDetails->user_id, true);
        return redirect('/parent');
          

    }
}
