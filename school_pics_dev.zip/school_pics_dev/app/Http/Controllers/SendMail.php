<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth;
use session;
use \App\Http\Requests;
 require base_path() . '/vendor/phpmailer/PHPMailerAutoload.php';


class SendMail extends Controller
{
	
    public function index(){
       
    	return view("test.form")->with('title','LaraMail');
       // return view('test.form',compact('classrooms'));
    }
    public function sendEmail(Request $request){
    	$mail = new \PHPMailer;
    	try{
    		$mail->isSMTP();
    		$mail->CharSet = 'utf-8';
            $mail->isSMTP();
            $mail->smtpConnect([
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ]);
            $mail->SMTPDebug = 2;
            $mail->SMTPAuth = false;
            $mail->SMTPSecure = 'tls';
    		//$mail->SMTPSecure = 'ssl';
            $token='fgfhh';
             $message = file_get_contents('http://schoolpics.co/public/parent_invitation.html'); 
            $message = str_replace('%token%', $token, $message); 

    		$mail->Host = "smtp.gmail.com"; //gmail has host > smtp.gmail.com
    		$mail->Port = 587; //gmail has port > 587 . without double quotes
    		$mail->Username = "web.xtapps@gmail.com"; //your username. actually your email
    		$mail->Password = "reshmaxtapps"; // your password. your mail password
    		$mail->setFrom($request->email, $request->name); 
    		$mail->Subject = $request->subject;
    		$mail->MsgHTML($message);
    		$mail->addAddress("reshma.xtapps@gmail.com" ,"namerecipient"); 
    		var_dump($mail->send());die();
    	}catch(phpmailerException $e){
    		dd($e);
    	}catch(Exception $e){
    		dd($e);
    	}
    	if($mail){
    		return View("result")->with("result","success")->with("title","Success");
    	}else{
    		return View("result")->with("result","failed")->with("title","Failed");
    	}
    }
}
