<?php

namespace App\Http\Controllers;
use \App\Invitation;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;
use \Mail;
use session;

require base_path() . '/vendor/phpmailer/PHPMailerAutoload.php';

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index($cid)
    {

        $classroom = \App\Classroom::find($cid);
        $students = \App\Student::where('classroom_id',$cid)->withCount('galleries')->get();;
      
        return view('student.index',compact(['students','classroom']));

    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($cid)
    {
        $classroom = \App\Classroom::find($cid);
        return view('student.create',compact('classroom'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,$cid)
    {
        $this->validate($request, [
        'first_name' => 'required',
        'last_name' => 'required'
        
    ]);

         $student = new \App\Student;
         $parentDetails = new \App\ParentDetail;
         $invitation= new \App\Invitation;
         $user= new \App\User;

         $student->first_name = $request->first_name;
         $student->last_name = $request->last_name;
         $student->classroom_id = $cid;
 
         $student->save();


        // $Checkuser = \App\User::where('email', $request->parent_email)->first();
        
        //     if(!$Checkuser){
        //         $user->first_name = $request->parent_first_name;
        //         $user->last_name = $request->parent_last_name;
        //         $user->email = $request->parent_email;
        //         $random_password=str_random(6);
        //         $user->password = bcrypt($random_password);
        //          $user->role_id = 3;
        //         $user->save();

        //          $parent_email=$request->parent_email;
        //      $parent_name=$request->parent_first_name;
        //      $parentDetails->first_name = $request->parent_first_name;
        //      $parentDetails->last_name = $request->parent_last_name;
        //      $parentDetails->email = $request->parent_email;
        //      $parentDetails->user_id = $user->id;
        //      $parentDetails->relation = $request->relation;
        //      $student->parentDetails()->save($parentDetails);

        //     $token=str_random(16);
        //     $invitation->invitaion_token=$token;
        //     $invitation->status=1;
        //     $parentDetails->invitations()->save($invitation);

        //      Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'random_password'=>$random_password,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$random_password,$parent_name, $token) {
        //                 $m->from('info@xtapps.com', 'School Pics');
        //                 $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
        //             }); 
        //  }else{
        //     $random_password='';
        //      $parent_email=$request->parent_email;
        //      $parent_name=$request->parent_first_name;
        //      $parentDetails->first_name = $request->parent_first_name;
        //      $parentDetails->last_name = $request->parent_last_name;
        //      $parentDetails->email = $request->parent_email;
        //      $parentDetails->relation = $request->relation;
        //      $parentDetails->user_id = $Checkuser->id;
        //      $student->parentDetails()->save($parentDetails);

        //     $token=str_random(16);
        //     $invitation->invitaion_token=$token;
        //     $invitation->status=1;
        //     $parentDetails->invitations()->save($invitation);
        //      Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$parent_name, $token) {
        //                 $m->from('info@xtapps.com', 'School Pics');
        //                 $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
        //             }); 
        //  }
       
        \Session::flash('success_msg', 'Student Added successfully!');
         return redirect('/classroom/'.$cid);
 
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($sid)
    {
        
        $student = \App\Student::find($sid);
        $galleries = \App\Gallery::all()->where('student_id',$sid)->sortByDesc('id');
        return view('student.show',compact(['student','galleries']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       // $student = \App\Student::where('id',$id)->with('parentDetails')->first();
        $student = \App\Student::where('id',$id)->first();
        //echo '<pre>';print_r($student);die();
        return view('student.edit',compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { 
         $this->validate($request, [
        'first_name' => 'required',
        'last_name'=>'required'
        ]);

        $student = \App\Student::where('id',$id)->with('parentDetails')->first();
      
         $student->first_name = $request->first_name;
         $student->last_name = $request->last_name;
         $student->save();
  if(isset($student->parentDetails)) { 

    $this->validate($request, [
        
        'parent_first_name'=>'required',
        'parent_email'=>'required|email',
        'parent_last_name' => 'required',
        'relation'=>'required'
        
        ]);

         $parentDetails = \App\ParentDetail::where('id', $student->parentDetails->id)->first();
         $userDetails = \App\User::find($parentDetails->user_id);
         $parent_email=$request->parent_email;
         $parent_name=$request->parent_first_name;
         $parent_lastname=$request->parent_last_name;
         $parentDetails->first_name = $request->parent_first_name;
         $parentDetails->last_name = $request->parent_last_name;
         $parentDetails->email = $request->parent_email;
         $parentDetails->relation = $request->relation;
         $student->parentDetails()->save($parentDetails);
            if(isset($userDetails))
            {
         $userDetails->first_name = $parent_name;
         $userDetails->last_name = $parent_lastname;
         //$userDetails->email = $request->parent_email;
         $userDetails->save();
             }
        $Checkuser = \App\User::where('email', $request->parent_email)->first();
         
         } 

        \Session::flash('success_msg', 'Student Updated successfully!');
         return redirect('/classroom/'.$student->classroom_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $student = \App\Student::find($id);
        $student->parentDetails()->delete();
        $student->galleries()->delete();
        $student->delete();


        return redirect()->back();
    }

  public function destroy1($id)
    {
        $galleries = \App\Gallery::find($id);
      
        $galleries->delete();
    
        \Session::flash('msg', 'Delete successfully!');
       
        return redirect::back();
                    
    }
    public function create_gallery($id)
    {
        $student = \App\Student::find($id);
        return view('student.gallery.create',compact('student'));
    }

    public function store_gallery(Request $request,$id){
    

        $this->validate($request, [
        
        'upload_image'=>'required|image'
        
    ]);
       
        $student = \App\Student::find($id);
         $img = Image::make($request->upload_image)->resize(200,null,function ($constraint) {
    $constraint->aspectRatio();
})->crop(200,150);
         $imageName = time().'.'.$request->upload_image->getClientOriginalExtension();
         $request->upload_image->move(public_path('images/'.$student->id.'/'), $imageName);
  
         $img->save(public_path('images/'.$id.'/').'thumbnail_'.$imageName.'');
          \Session::flash('success_msg', 'Image Added successfully!');
         $gallery = new \App\Gallery;

         $gallery->student_id = $id;
         $gallery->image ='/images/'.$student->id.'/'.$imageName;
        $gallery->thumbnail = '/images/'.$id.'/'.'thumbnail_'.$imageName.'';
        $gallery->image_name = 'NULL';
        $gallery->image_description = $request->image_description;

        $gallery->save();
    
          // return $img->response('jpg');

        return redirect('/student/'.$id.'/gallery');
    }

    public function invite($id){
        $student = \App\Student::find($id);
        $parent_details = \App\ParentDetail::where('student_id',$student->id)->first();
        // $parentDetails = new \App\ParentDetail;

        if(isset($parent_details)){
        $invitations = \App\Invitation::where('parent_detail_id',$parent_details->id)->first();

        $user = new \App\User;
        if(isset($invitations)){
        $invitation = $invitations;

        }else{
        $invitation = new \App\Invitation;

        }
    }
        if(isset($parent_details)){
            $parent = $parent_details;
         
            $Checkuser = \App\User::where('email', $parent->email)->first();
        
            if(!$Checkuser){
                // $user->first_name = $parent->first_name;
                // $user->last_name = $parent->last_name;
                // $user->email = $parent->parent_email;
                // $random_password=str_random(6);
                // $user->password = bcrypt($random_password);
                //  $user->role_id = 3;
                // $user->save();

                 $parent_email=$parent->email;
             $parent_name=$parent->first_name;
            

            $token=str_random(16);
            $invitation->invitaion_token=$token;
            $invitation->status=1;
            $parent->invitations()->save($invitation);

            /* Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$parent_name, $token) {
                        $m->from('info@xtapps.com', 'School Pics');
                        $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
                    }); */
        $mail = new \PHPMailer;
        try{
            $mail->isSMTP();
            $mail->CharSet = 'utf-8';
            $mail->isSMTP();
            $mail->smtpConnect([
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ]);
            $mail->SMTPDebug = 2;
            $mail->SMTPAuth = false;
            $mail->SMTPSecure = 'tls';
            //$mail->SMTPSecure = 'ssl';
             $message = file_get_contents('http://schoolpics.co/public/parent_invitation.html'); 
            $message = str_replace('%token%', 'http://schoolpics.co/parent/token/'.$token, $message); 

            $mail->Host = "smtp.gmail.com"; //gmail has host > smtp.gmail.com
            $mail->Port = 587; //gmail has port > 587 . without double quotes
            $mail->Username = "web.xtapps@gmail.com"; //your username. actually your email
            $mail->Password = "reshmaxtapps"; // your password. your mail password
            $mail->setFrom('info@xtapps.com', 'School Pics'); 
            $mail->Subject = 'Welcome to School Pics';
            $mail->MsgHTML($message);
            $mail->addAddress($parent_email ,$parent_name); 
            $mail->send();
        }catch(phpmailerException $e){
            dd($e);
        }catch(Exception $e){
            dd($e);
        }
        \Session::flash('invite_msg', 'Invite sent successfully!');
                    
                    return redirect()->back();
         }else{
           
             $parent_email=$parent->email;
             $parent_name=$parent->first_name;
           
            $token=str_random(16);
            $invitation->invitaion_token=$token;
            $invitation->status=1;
            $parent_details->invitations()->save($invitation);
             /*Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$parent_name, $token) {
                        $m->from('info@xtapps.com', 'School Pics');
                        $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
                    }); */
              $mail = new \PHPMailer;
                try{
                    $mail->isSMTP();
                    $mail->CharSet = 'utf-8';
                    $mail->isSMTP();
                    $mail->smtpConnect([
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        ]
                    ]);
                    $mail->SMTPDebug = 2;
                    $mail->SMTPAuth = false;
                    $mail->SMTPSecure = 'tls';
                    //$mail->SMTPSecure = 'ssl';
                     $message = file_get_contents('http://schoolpics.co/public/parent_invitation.html'); 
                    $message = str_replace('%token%', 'http://schoolpics.co/parent/token/'.$token, $message); 

                    $mail->Host = "smtp.gmail.com"; //gmail has host > smtp.gmail.com
                    $mail->Port = 587; //gmail has port > 587 . without double quotes
                    $mail->Username = "web.xtapps@gmail.com"; //your username. actually your email
                    $mail->Password = "reshmaxtapps"; // your password. your mail password
                    $mail->setFrom('info@xtapps.com', 'School Pics'); 
                    $mail->Subject = 'Welcome to School Pics';
                    $mail->MsgHTML($message);
                    $mail->addAddress($parent_email ,$parent_name); 
                    $mail->send();
                }catch(phpmailerException $e){
                    dd($e);
                }catch(Exception $e){
                    dd($e);
                }
         }
       
        \Session::flash('invite_msg', 'Invite sent successfully!');
            return redirect()->back();
           
        }else{

        
        return view('student.invite',compact('student'));
        }
    }

    public function addParent(Request $request,$id){
        $this->validate($request, [
            'parent_first_name' => 'required',
            'parent_email'=>'required|email',
            'parent_last_name' => 'required',
            'relation'=>'required'
    
        ]);
        $Checkuser = \App\User::where('email', $request->parent_email)->first();
        $user = new \App\User;
        $parentDetails = new \App\ParentDetail;
        $student = \App\Student::find($id);
        $invitation = new \App\Invitation;
            if(!$Checkuser){
                // $user->first_name = $request->parent_first_name;
                // $user->last_name = $request->parent_last_name;
                // $user->email = $request->parent_email;
                // $random_password=str_random(6);
                // $user->password = bcrypt($random_password);
                //  $user->role_id = 3;
                // $user->save();

                 $parent_email=$request->parent_email;
             $parent_name=$request->parent_first_name;
             $parentDetails->first_name = $request->parent_first_name;
             $parentDetails->last_name = $request->parent_last_name;
             $parentDetails->email = $request->parent_email;
             $parentDetails->user_id = $user->id;
            
             $parentDetails->relation = $request->relation;
             $student->parentDetails()->save($parentDetails);

            $token=str_random(16);
            $invitation->invitaion_token=$token;
            $invitation->status=1;
            $parentDetails->invitations()->save($invitation);

             /*Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$parent_name, $token) {
                        $m->from('info@xtapps.com', 'School Pics');
                        $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
                    }); */
                 $mail = new \PHPMailer;
                try{
                    $mail->isSMTP();
                    $mail->CharSet = 'utf-8';
                    $mail->isSMTP();
                    $mail->smtpConnect([
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        ]
                    ]);
                    $mail->SMTPDebug = 2;
                    $mail->SMTPAuth = false;
                    $mail->SMTPSecure = 'tls';
                    //$mail->SMTPSecure = 'ssl';
                     $message = file_get_contents('http://schoolpics.co/public/parent_invitation.html'); 
                    $message = str_replace('%token%', 'http://schoolpics.co/parent/token/'.$token, $message); 

                    $mail->Host = "smtp.gmail.com"; //gmail has host > smtp.gmail.com
                    $mail->Port = 587; //gmail has port > 587 . without double quotes
                    $mail->Username = "web.xtapps@gmail.com"; //your username. actually your email
                    $mail->Password = "reshmaxtapps"; // your password. your mail password
                    $mail->setFrom('info@xtapps.com', 'School Pics'); 
                    $mail->Subject = 'Welcome to School Pics';
                    $mail->MsgHTML($message);
                    $mail->addAddress($parent_email ,$parent_name); 
                    $mail->send();
                }catch(phpmailerException $e){
                    dd($e);
                }catch(Exception $e){
                    dd($e);
                }
                    \Session::flash('invite_msg', 'Invite sent successfully!');
        
        return redirect('/classroom/'.$student->classroom_id);
                    
         }else{
            $random_password='';
             $parent_email=$request->parent_email;
             $parent_name=$request->parent_first_name;
             $parentDetails->first_name = $request->parent_first_name;
             $parentDetails->last_name = $request->parent_last_name;
             $parentDetails->email = $request->parent_email;
             $parentDetails->relation = $request->relation;
             $parentDetails->student_id = $id;
             $parentDetails->user_id = $Checkuser->id;
             $student->parentDetails()->save($parentDetails);

            $token=str_random(16);
            $invitation->invitaion_token=$token;
            $invitation->status=1;
            $parentDetails->invitations()->save($invitation);
             /*Mail::send('emails.parent_invitation', ['parent_email' => $parent_email,'parent_name'=>$parent_name, 'token' => $token], function ($m) use ($parent_email,$parent_name, $token) {
                        $m->from('info@xtapps.com', 'School Pics');
                        $m->to($parent_email,$parent_name)->subject('Welcome to School Pics');
                    });*/ 
             $mail = new \PHPMailer;
                try{
                    $mail->isSMTP();
                    $mail->CharSet = 'utf-8';
                    $mail->isSMTP();
                    $mail->smtpConnect([
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        ]
                    ]);
                    $mail->SMTPDebug = 2;
                    $mail->SMTPAuth = false;
                    $mail->SMTPSecure = 'tls';
                    //$mail->SMTPSecure = 'ssl';
                     $message = file_get_contents('http://schoolpics.co/public/parent_invitation.html'); 
                    $message = str_replace('%token%', 'http://schoolpics.co/parent/token/'.$token, $message); 

                    $mail->Host = "smtp.gmail.com"; //gmail has host > smtp.gmail.com
                    $mail->Port = 587; //gmail has port > 587 . without double quotes
                    $mail->Username = "web.xtapps@gmail.com"; //your username. actually your email
                    $mail->Password = "reshmaxtapps"; // your password. your mail password
                    $mail->setFrom('info@xtapps.com', 'School Pics'); 
                    $mail->Subject = 'Welcome to School Pics';
                    $mail->MsgHTML($message);
                    $mail->addAddress($parent_email ,$parent_name); 
                    $mail->send();
                }catch(phpmailerException $e){
                    dd($e);
                }catch(Exception $e){
                    dd($e);
                }
         }
         \Session::flash('invite_msg', 'Invite sent successfully!');
        return redirect("/classroom/$student->classroom_id");
    }
}
