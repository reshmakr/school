$(document).ready(function(){

   var url = window.location.href;
   if (url.indexOf("#login") >= 0){
      $('#login-link').click();
   }
      

$('#signupForm').submit(function(e){
	e.preventDefault();
	$('#signupSubmit').css('display','none');
	$('.loader').css('display','block');
	//console.log(e.target.first_name.value);
  console.log(e.target.role_id.value); 
	 $('#first_name_error').html('');
    $('#email_error').html('');
    $('#password_error').html('');
 var registerUrl=window.location.href+'register';
$.ajax(registerUrl, {
            type: 'POST',  
            data: {

    first_name: e.target.first_name.value,
    last_name: e.target.last_name.value,
    email:e.target.email.value,
    school_name:e.target.school_name.value,
    school_address:e.target.school_address.value,
    role_id:e.target.role_id.value,
    avatar:'default.jpg',
    password:e.target.password.value,
    password_confirmation:e.target.password_confirmation.value},  // data to submit
            success: function (data, status, xhr) {
               //console.log(data.auth);
               //console.log(data.user.role_id);
               if(data.user.role_id==1){
                window.location.href= window.location.href.replace(/#.*$/, '').replace(/\?.*$/, '')+'classrooms';
              }else{
                window.location.href= window.location.href.replace(/#.*$/, '').replace(/\?.*$/, '')+'parent';
              }
               //window.location.href= window.location.href+'classrooms';
     //            $('#signupSubmit').css('display','block');
					// $('.loader').css('display','none');
					console.log(data.user);
					
            },
            error: function (jqXhr, textStatus, errorMessage) {
                  console.log(jqXhr.responseJSON);
                  var error = jqXhr.responseJSON;
                  if(error.first_name){
                  var first_nameError = error.first_name[0];
                  $('#first_name_error').html('*'+first_nameError);

              }
              if(error.email){
              var emailError = error.email[0];
              $('#email_error').html('*'+emailError);

              }
              if(error.role_id){
                  var roleError = error.role_id[0];
                  $('#role_error').html('*The Account type field is required.');

              }
              if(error.password)
              {
              	  var passwordError = error.password[0];
                  $('#password_error').html('*'+passwordError);
              }
                
                  $('#signupSubmit').css('display','block');
					$('.loader').css('display','none');
                }
        });
  
})

$('#signinForm').submit(function(e){
e.preventDefault();
 var loginUrl=window.location.href.replace(/#.*$/, '').replace(/\?.*$/, '');
$.ajax(loginUrl+'login', {
            type: 'POST',  // http method
            data: { email:e.target.signinEmail.value,
            password:e.target.signinPassword.value },  // data to submit
            success: function (data, status, xhr) {
              //console.log(data.auth);
              if(data.user.role_id==1){
                window.location.href= window.location.href.replace(/#.*$/, '').replace(/\?.*$/, '')+'classrooms';
              }else{
                window.location.href= window.location.href.replace(/#.*$/, '').replace(/\?.*$/, '')+'parent';
              }
            	//window.location.href = data.intended;
            	//window.location.href= window.location.href+'classrooms';
                console.log(data,status);
            },
            error: function (jqXhr, textStatus, errorMessage) {
                    console.log(jqXhr.responseJSON);
                    //alert(jqXhr.responseJSON.email);
                    if(jqXhr.responseJSON.email){
                    	var emailError2 = jqXhr.responseJSON.email[0];
                    	$('#email_error_2').html(jqXhr.responseJSON.email);
                    }

                    if(jqXhr.responseJSON.password){
                    	var passwordError2 = jqXhr.responseJSON.password[0];
                    	$('#password_error_2').html(passwordError2);


                    }
                }
        });
})
});

function getAccountType(sel){
  if(sel.value==1){
    $('#role_type_display').show();
  }else{
    $('#role_type_display').hide();
  }
}
